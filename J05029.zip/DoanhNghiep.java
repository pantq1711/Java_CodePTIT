/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class DoanhNghiep implements Comparable <DoanhNghiep> {
    
    private String ID, name;
    
    private int so_Luong;

    public DoanhNghiep(String ID, String name, int so_Luong) {
        this.ID = ID;
        this.name = name;
        this.so_Luong = so_Luong;
    }
    
    @Override
    public int compareTo(DoanhNghiep o)
    {
        if(this.so_Luong == o.so_Luong) return this.ID.compareTo(o.ID);
        return o.so_Luong - this.so_Luong;
    }

    public int getSo_Luong() {
        return so_Luong;
    }
    
    @Override
    public String toString()
    {
        return ID + " " + name + " " + Integer.toString(so_Luong);
    }
}
