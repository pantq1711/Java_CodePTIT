/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.util.Date;
public class KhachHang implements Comparable<KhachHang>{
    private String ID, Name, ID_Room;
    private Date Start_day, End_day;
    private long days_of_Stay;

    public KhachHang(int ID, String Name, String ID_Room, Date Start_day, Date End_day) {
        this.ID = "KH" +  String.format("%02d", ID);
        this.Name = Name;
        this.ID_Room = ID_Room;
        this.Start_day = Start_day;
        this.End_day = End_day;
        this.days_of_Stay = (End_day.getTime() - Start_day.getTime()) / (1000l * 60 * 60 *  24);
    }
    @Override
    public int compareTo(KhachHang o){
        return (int)(o.days_of_Stay - this.days_of_Stay);
    }

    @Override
    public String toString() {
        return this.ID + " " + this.Name + " " + this.ID_Room + " " + this.days_of_Stay;
    }
    
}
