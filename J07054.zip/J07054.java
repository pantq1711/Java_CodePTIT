import java.util.*;
import java.io.FileNotFoundException;
import java.io.File;
public class J07054 {
    public static void main(String[] args) throws FileNotFoundException{
        Scanner sc = new Scanner(new File("BANGDIEM.in"));
        ArrayList <SinhVien> arr = new ArrayList<>();
        int n = Integer.parseInt(sc.nextLine());
        for(int i=0; i<n; ++i){
            arr.add(new SinhVien(sc.nextLine(), Double.parseDouble(sc.nextLine()), Double.parseDouble(sc.nextLine()), Double.parseDouble(sc.nextLine())));
        }
        Collections.sort(arr);
        arr.get(0).setrank(1);
        System.out.println(arr.get(0));
        
        for(int i=1; i<n; ++i){
            if(arr.get(i).getdiemtb() == arr.get(i-1).getdiemtb()) arr.get(i).setrank(arr.get(i-1).getrank());
            else {
                arr.get(i).setrank(i + 1);
            }
            System.out.println(arr.get(i));
        }
    }
}