import java.util.*;
public class SinhVien implements Comparable<SinhVien> {
    
    private static int cnt = 1;
    private String ID, name;
    private double diem1, diem2, diem3;
    private double diemtb;
    private int rank;
    
    public String chuanhoa(String s){
        String res = "";
        String [] words = s.trim().split("\\s+");
        for(String word : words) res += word.toUpperCase().charAt(0) + word.toLowerCase().substring(1) + " ";
        return res.trim();
    }
    
    public SinhVien(String name, double diem1, double diem2, double diem3) {
        this.ID = String.format("SV%02d", cnt++);
        this.name = chuanhoa(name);
        this.diem1 = diem1;
        this.diem2 = diem2;
        this.diem3 = diem3;
        this.diemtb = (diem1 * 3 + diem2 * 3 + diem3 * 2) / 8;
    }
    
    public double getdiemtb(){
        return this.diemtb;
    }
    
    public void setrank(int n){
        this.rank = n;
    }
    
    public int getrank(){
        return this.rank;
    }
    
    @Override
    public int compareTo(SinhVien o){
        if(this.diemtb == o.diemtb) return this.ID.compareTo(o.ID);
        if(this.diemtb < o.diemtb) return 1;
        return -1;
    }
    
    @Override
    public String toString(){
        return String.format("%s %s %.2f %d", this.ID, this.name, this.diemtb, this.rank);
    }
}
