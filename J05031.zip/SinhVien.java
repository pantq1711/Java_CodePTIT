/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class SinhVien implements Comparable <SinhVien> {
    
    public static int cnt = 0;
    
    
    private String ID, name, class_SV;
    
    private double diem1, diem2, diem3;

    public SinhVien(String ID, String name, String class_SV, double diem1, double diem2, double diem3) {
        this.ID = ID;
        this.name = name;
        this.class_SV = class_SV;
        this.diem1 = diem1;
        this.diem2 = diem2;
        this.diem3 = diem3;
    }
    
    @Override
    public int compareTo(SinhVien o)
    {
        return this.name.compareTo(o.name);
    }
    
    @Override
    public String toString()
    {
        return String.format("%d %s %s %s %.1f %.1f %.1f", ++cnt, ID, name, class_SV, diem1, diem2, diem3);
    }
}
