/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.text.DecimalFormat;
public class MatHang {
   
    public DecimalFormat df = new DecimalFormat("#");
    
    public static int cnt = 0;
    
    public String ID, ten, don_vi;
    
    public int don_gia, so_luong;
    
    public double phi_van_chuyen, tong_tien;
    
    public double gia_ban;

    public MatHang(String ten, String don_vi, int don_gia, int so_luong) {
        this.ID = String.format("MH%02d", ++cnt);
        this.ten = ten;
        this.don_vi = don_vi;
        this.don_gia = don_gia;
        this.so_luong = so_luong;
        this.phi_van_chuyen = Math.round(don_gia * so_luong * 5 / 100);
        this.tong_tien = Math.round(don_gia * so_luong + this.phi_van_chuyen);
        this.gia_ban = Math.round(this.tong_tien * 102 / 100);
    }
    
    @Override
    public String toString()
    {
        return String.format("%s %s %s %.0f %.0f %.0f", ID, ten, don_vi, phi_van_chuyen, tong_tien, gia_ban);
    }
    
}
