/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class IntSet {
    private TreeSet<Integer> set;

    public IntSet(int [] a) {
        ArrayList <Integer> arr = new ArrayList<>();
        for(int x : a) arr.add(x);
        this.set = new TreeSet<>(arr);
    }
    
    public IntSet(ArrayList<Integer> arr){
        this.set = new TreeSet<>(arr);
    }
    
    public IntSet union(IntSet a){
        ArrayList <Integer> arr = new ArrayList<>();
        for(Integer x : a.set) arr.add(x);
        for(Integer x : this.set) arr.add(x);
        return new IntSet(arr);
    }
    
    @Override
    public String toString(){
        String res = "";
        for(Integer num : this.set) res += num.toString() + " ";
        return res.trim();
    }
}
