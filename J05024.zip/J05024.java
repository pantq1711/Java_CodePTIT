import java.util.*;
public class J05024 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = Integer.parseInt(sc.nextLine());
        ArrayList <SinhVien> arr = new ArrayList <>();
        for(int i=1; i<=n; ++i) arr.add(new SinhVien(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine()));
        int q = Integer.parseInt(sc.nextLine());
        while (q-- > 0) {
            String t = sc.nextLine().toUpperCase();
            System.out.println("DANH SACH SINH VIEN NGANH " + t + ":");
            for (SinhVien sv : arr) {
                if (sv.getLop_hoc().charAt(0) == 'E' && (sv.getID().charAt(5) == 'A' || sv.getID().charAt(5) == 'C')) continue; 
                if(sv.getID().charAt(5) == t.charAt(0))
                {
                    System.out.println(sv);
                }
            }
        }
    }
}
//4
//B16DCCN011
//Nguyen Trong Duc Anh
//D16CNPM1
//sv1@stu.ptit.edu.vn
//B15DCCN215
//To Ngoc Hieu
//D15CNPM3
//sv2@stu.ptit.edu.vn
//B15DCCN150
//Nguyen Ngoc Son
//E15CQCN02-B
//sv3@stu.ptit.edu.vn
//B15DCKT199
//Nguyen Trong Tung
//D15CQKT02-B
//sv4@stu.ptit.edu.vn
//2
//Ke toan
//Cong nghe thong tin