/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
public class SinhVien {
    private String ID, Name, lop_hoc, Email;

    public SinhVien(String ID, String Name, String lop_hoc, String Email) {
        this.ID = ID;
        this.Name = Name;
        this.lop_hoc = lop_hoc;
        this.Email = Email;
    }

    public String getID() {
        return ID;
    }

    public String getLop_hoc() {
        return lop_hoc;
    }
    
    @Override
    public String toString(){
        return this.ID + " " + this.Name + " " + this.lop_hoc + " " + this.Email;
    }
}
