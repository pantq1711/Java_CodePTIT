/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class J05064 {
    public static boolean check(String s, Map <String, Integer> map)
    {
        if (s.equals("HT") && map.get(s) != 1) return false;
        if (s.equals("HP") && map.get(s) > 2) return false;
        return true;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = Integer.parseInt(sc.nextLine());
        ArrayList <GiaoVien> arr = new ArrayList <>();
        Map <String, Integer> map = new LinkedHashMap <>();
        while(t-- >0) arr.add(new GiaoVien(sc.nextLine(), sc.nextLine(), Integer.parseInt(sc.nextLine())));
        for(GiaoVien gv : arr)
        {   
            String tmp = gv.getID().substring(0, 2);
            if(map.containsKey(tmp)){
            map.put(tmp, map.get(tmp) + 1);
        }
        else map.put(tmp, 1);
            if(check(tmp, map)) System.out.println(gv);
        }
    }
}
//5
//HT01
//Nguyen Kim Loan
//1420000
//HT05
//Hoang Thanh Tuan
//1780000
//HT02
//Tran Binh Nguyen
//1468000
//HP01
//Nguyen Kim Loan
//1420000
//HP05
//Hoang Thanh Tuan
//1780000