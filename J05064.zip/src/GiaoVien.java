/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class GiaoVien {
    Map <String, Integer> map = new LinkedHashMap<>();
    
    private String ID, ten;
    
    private int luongCoBan;

    public GiaoVien(String ID, String ten, int luongCoBan) {
        this.ID = ID;
        this.ten = ten;
        this.luongCoBan = luongCoBan;    
    }

    public String getID() {
        return ID;
    }
    
    
    public int getPhuCap()
    {
        char c = ID.charAt(1);
        if(c == 'T') return 2000000;
        else if(c == 'P') return 900000;
        else return 500000;
    }
    
    public int luong()
    {
        int heso = Integer.parseInt(ID.substring(2));
        return heso * luongCoBan + getPhuCap();
    }
    
    @Override
    public String toString()
    {
        return ID + " " + ten + " " + Integer.parseInt(ID.substring(2)) + " " + getPhuCap() + " " + luong(); 
    }
}
