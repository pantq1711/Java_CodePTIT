/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.text.ParseException;
public class J05082 {
    
    public static void main(String[] args) throws ParseException {
        
        Scanner sc = new Scanner(System.in);
        int t = Integer.parseInt(sc.nextLine());
        ArrayList <KhachHang> arr = new ArrayList <>();
        while(t-- >0) arr.add(new KhachHang(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine()));
        Collections.sort(arr);
        for(KhachHang kh : arr)
        {
            System.out.println(kh);
        }
    }
}
//2
// nGuyen VAN     nAm
//Nam
//12/12/1997
//Mo Lao-Ha Dong-Ha Noi
// TRan    vAn     biNh
//Nam
//14/11/1995
//Phung Khoang-Nam Tu Liem-Ha Noi