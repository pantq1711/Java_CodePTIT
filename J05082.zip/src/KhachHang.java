/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Date;
import java.time.temporal.ChronoUnit;
public class KhachHang implements Comparable <KhachHang> {
    
    public static int stt = 0;
    
    private String ID, name, sex, date;
    
    private Date dateOfBirth;
    
    Date cur_date = new Date();
    
    private String address;
    
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    
    public static String convertdate(String s)
    {
        StringBuilder tmp = new StringBuilder(s);
        if(tmp.charAt(1) == '/') tmp.insert(0, "0");
        if(tmp.charAt(4) == '/')  tmp.insert(3, "0");
        return tmp.toString();
    }
    
    public static String convertname(String s){
        String res = "";
        String [] words = s.trim().split("\\s+");
        for(String word : words) res += word.toUpperCase().charAt(0) + word.toLowerCase().substring(1) + " ";
        return res.trim();
    }

    public KhachHang(String name, String sex, String dateOfBirth, String address) throws ParseException{
        this.ID = String.format("KH%03d", ++stt);
        this.name = convertname(name);
        this.sex = sex;
        this.date = convertdate(dateOfBirth);
        this.dateOfBirth = sdf.parse(convertdate(dateOfBirth));
        this.address = address;
    }
    
    public int getDate(){
        return (int)ChronoUnit.DAYS.between(dateOfBirth.toInstant(), cur_date.toInstant());
    }
    
    @Override
    public int compareTo(KhachHang o)
    {
        return o.getDate() - this.getDate();
    }
    
    @Override
    public String toString(){
        return ID + " " + name + " " + sex +  " " + address + " " + date;
    }
}
