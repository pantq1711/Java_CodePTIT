import java.util.*;
public class IntSet {
    private TreeSet<Integer> set = new TreeSet<>();
    
    public IntSet(ArrayList<Integer> arr){
        this.set = new TreeSet<>(arr);
    }
    
    public IntSet intersection(IntSet a){
        ArrayList <Integer> arr2 = new ArrayList<>();
        for(Integer x : this.set) arr.add(x);
        for(Integer x : a.set) if(arr.contains(x)) arr2.add(x);
        return new IntSet(arr2);
    }
    
    @Override
    public String toString(){
        String res = "";
        for(Integer x : this.set) res += x.toString() + " ";
        return res.trim();
    }
}
