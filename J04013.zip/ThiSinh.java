/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class ThiSinh {
    private String ID, name;
    
    private double diem_Toan, diem_Ly, diem_Hoa, tong_Diem;

    public static String chuanhoa(String s){
        String res = "";
        String words [] = s.trim().split("\\s+");
        for(String word : words) res += word.toUpperCase().charAt(0) + word.toLowerCase().substring(1) + " ";
        return res.trim();
    }
    
    public double getdiem_cong(){
        char c = this.ID.charAt(2);
        if(c == '1') return 0.5;
        else if(c == '2') return 1.0;
        else return 2.5;
    }
    
    public ThiSinh(String ID, String name, double diem_Toan, double diem_Ly, double diem_Hoa) {
        this.ID = ID;
        this.name = chuanhoa(name);
        this.diem_Toan = diem_Toan;
        this.diem_Ly = diem_Ly;
        this.diem_Hoa = diem_Hoa;
        this.tong_Diem = this.diem_Toan * 2 + this.diem_Hoa + this.diem_Ly;
    }
    
    
    public String get_Status(){
        if(this.tong_Diem + this.getdiem_cong() >= 24) return "TRUNG TUYEN";
        else return "TRUOT";
    }
    
    @Override
    public String toString(){
        if(this.getdiem_cong() != (int)this.getdiem_cong() && this.tong_Diem != (int)this.tong_Diem)
        return String.format("%s %s %.1f %.1f %s", this.ID, this.name, this.getdiem_cong(), this.tong_Diem, this.get_Status());
        else if(this.getdiem_cong() != (int)this.getdiem_cong() && this.tong_Diem == (int)this.tong_Diem)
        return String.format("%s %s %.1f %d %s", this.ID, this.name, this.getdiem_cong(), (int)this.tong_Diem, this.get_Status());    
        else if(this.getdiem_cong() == (int)this.getdiem_cong() && this.tong_Diem != (int)this.tong_Diem)
        return String.format("%s %s %d %.1f %s", this.ID, this.name, (int)this.getdiem_cong(), this.tong_Diem, this.get_Status());
        else 
        return String.format("%s %s %d %d %s", this.ID, this.name, (int)this.getdiem_cong(), (int)this.tong_Diem, this.get_Status());
    }
}
