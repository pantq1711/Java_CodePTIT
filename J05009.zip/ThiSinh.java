/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class ThiSinh implements Comparable <ThiSinh> {
    
    public static int cnt = 0;
    
    private String name, date_Of_Birth;
    
    private int ID;
    
    private double diem1, diem2, diem3, tong_diem;

    public ThiSinh(String name, String date_Of_Birth, double diem1, double diem2, double diem3) {
        this.ID =  ++cnt;
        this.name = name;
        this.date_Of_Birth = date_Of_Birth;
        this.diem1 = diem1;
        this.diem2 = diem2;
        this.diem3 = diem3;
    }
    
    public double get_tong_diem(){
        return diem1 + diem2 + diem3;
    }
    
    @Override
    public int compareTo(ThiSinh o)
    {
        if(this.get_tong_diem() > o.get_tong_diem()) return 1;
        else if(this.get_tong_diem() < o.get_tong_diem()) return -1;
        else return this.ID - o.ID;
    }
    
    @Override
    public String toString()
    {
        return this.ID + " " + this.name + " " + this.date_Of_Birth + " " + this.get_tong_diem();
    }
}
