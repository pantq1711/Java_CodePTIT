/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class J05077 {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        ArrayList <PhongBan> arr = new ArrayList <>();
        Map <String, PhongBan> map = new HashMap <>();
        int t = Integer.parseInt(sc.nextLine());
        for(int i=0; i<t; ++i){
            PhongBan pb = new PhongBan(sc.nextLine());
            map.put(pb.getID(), pb);
        }
        t = Integer.parseInt(sc.nextLine());
        ArrayList <NhanVien> arr1 = new ArrayList <>();
        while(t-- >0)
        {
            NhanVien nv = new NhanVien(sc.nextLine(), sc.nextLine(), Integer.parseInt(sc.nextLine()), Integer.parseInt(sc.nextLine()));
            arr1.add(nv);
            nv.setName(map.get(nv.getID_NV()).getName());
        }
        for(NhanVien nv : arr1)
        {
            System.out.println(nv);
        }
    }
}
//2
//HC Hanh chinh
//KH Ke hoach Dau tu
//2
//C06HC
//Tran Binh Minh
//65
//25
//D03KH
//Le Hoa Binh
//59
//24