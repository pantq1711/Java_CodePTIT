/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
public class Triangle {
    
    private double canh1, canh2, canh3;

    public Triangle(Point a, Point b, Point c) {
        this.canh1 = a.dis(b);
        this.canh2 = a.dis(c);
        this.canh3 = b.dis(c);
    }
    
    public boolean valid(){
        if(this.canh1 + this.canh2 > this.canh3 && this.canh1 + this.canh3 > this.canh2 && this.canh2 + this.canh3 > this.canh1) return true;
        return false;
    }
    
    public String getPerimeter(){
        return String.format("%.3f", this.canh1 + this.canh2 + this.canh3);
    }
}
