
import java.util.*;
public class J05072 {
    
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        Map <Integer, ThanhPho> map = new LinkedHashMap <>();
        int t = Integer.parseInt(sc.nextLine());
        while(t-- >0)
        {
            ThanhPho tp = new ThanhPho(Integer.parseInt(sc.nextLine()), sc.nextLine(), Integer.parseInt(sc.nextLine()));
            map.put(tp.getID(), tp);
        }
        t = Integer.parseInt(sc.nextLine());
        ArrayList <CuocGoi> arr = new ArrayList <>();
        for(int i=0; i<t; ++i)
        {
            CuocGoi cg = new CuocGoi(sc.nextLine());
            if(cg.getIDCity().charAt(0) != '0') 
            {
                cg.setCityLocation("Noi mang"); 
                cg.setGiaCuoc(800);
            }
            else 
            {
                cg.setCityLocation(map.get(Integer.parseInt(cg.getIDCity())).getName());
                cg.setGiaCuoc(map.get(Integer.parseInt(cg.getIDCity())).getPrice());
            }
            arr.add(cg);
        }
        Collections.sort(arr);
        for(CuocGoi cg : arr)
        {
            int res = cg.getTime();
            if(cg.getIDCity().charAt(0) != '0')
                res *= 800;
            else res *= map.get(Integer.parseInt(cg.getIDCity().substring(1))).getPrice();
            System.out.println(String.format("%s %d", cg, res));
        }
    }
}
//2
//53
//Da Nang
//3000
//64
//Vung Tau
//1000
//3
//064-824531 11:20 11:22
//8293567 09:07 09:15
//053-823532 12:00 12:05