/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class HoaDon implements Comparable <HoaDon> {
    
    private String ma, ten;
    
    private long SL;
    
    private long donGia, tienChietKhau;

    public HoaDon(String ma, String ten, long SL, long donGia, long tienChietKhau) {
        this.ma = ma;
        this.ten = ten;
        this.SL = SL;
        this.donGia = donGia;
        this.tienChietKhau = tienChietKhau;
    }
    
    public long tienThanhToan()
    {
        return donGia * SL - tienChietKhau;
    }
    
    @Override
    public int compareTo(HoaDon o)
    {
        if(this.tienThanhToan() > o.tienThanhToan()) return -1;
        else return 1;
    }
    
    @Override
    public String toString()
    {
        return ma + " " + ten + " " + SL + " " + donGia + " " + tienChietKhau + " " + tienThanhToan();
    }
}