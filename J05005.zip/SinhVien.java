/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class SinhVien implements Comparable<SinhVien> {
    
    public static int cnt = 1;
    
    private String ID, name, Class, date_Of_Birth;
    
    private double gpa;

    private static String chuanhoa_ns(String s){
        StringBuilder tmp = new StringBuilder(s);
        if(tmp.charAt(1) == '/') tmp.insert(0, "0");
        if(tmp.charAt(4) == '/') tmp.insert(3, "0");
        return tmp.toString();
    }
    
    private static String chuanhoa_ten(String s){
        String res = "";
        String words [] = s.trim().split("\\s+");
        for(String word : words) res += word.toUpperCase().charAt(0) + word.toLowerCase().substring(1) + " ";
        return res.trim();
    }
    
    public SinhVien(String name, String Class, String date_Of_Birth, double gpa) {
        this.ID = String.format("B20DCCN%03d", cnt++);
        this.name = chuanhoa_ten(name);
        this.Class = Class;
        this.date_Of_Birth = chuanhoa_ns(date_Of_Birth);
        this.gpa = gpa;
    }
    
    @Override
    public int compareTo(SinhVien o)
    {
        if(this.gpa < o.gpa) return 1;
        return -1;
    }

    @Override 
    public String toString()
    {
        return this.ID + " " + this.name + " " + this.Class + " " + this.date_Of_Birth + " " + String.format("%.2f", this.gpa);
    }
    
}
