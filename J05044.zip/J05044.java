import java.util.*;
public class J05044 {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = Integer.parseInt(sc.nextLine());
        ArrayList <NhanVien> arr = new ArrayList <>();
        while(t-- >0) arr.add(new NhanVien(sc.nextLine(), sc.nextLine(), Integer.parseInt(sc.nextLine()), Integer.parseInt(sc.nextLine())));
        String s = sc.nextLine();
        for(NhanVien nv : arr)
        {
            if(nv.getChuc_vu().compareTo(s) == 0)
            System.out.println(nv);
        }
    }
}
//4
//Tran Thi Yen
//NV
//1000
//24
//Nguyen Van Thanh
//BV
//1000
//30
//Doan Truong An
//TP
//3000
//25
//Le Thanh
//GD
//5000
//28
//TP