/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class SanPham {
    
    private String ma;
    
    private double nhap;

    public SanPham(String ma, double nhap) {
        this.ma = ma;
        this.nhap = nhap;
    }
    
    public double soLuongXuatHang()
    {
        if(ma.charAt(0) == 'A') return Math.round(nhap * 60 / 100);
        else return Math.round(nhap * 70 / 100); 
    }
    
    public double donGia(){
        if(ma.charAt(ma.length() - 1) == 'Y') return 110000;
        else return 135000;
    }
    
    public double Tien(){
        return donGia() * soLuongXuatHang();
    }
    
    public double Thue(){
        char dau = ma.charAt(0);
        char cuoi = ma.charAt(ma.length() - 1);
        if(dau == 'A' && cuoi == 'Y') return Math.round(Tien() * 8 / 100);
        else if(dau == 'A' && cuoi == 'N') return  Math.round(Tien() * 11 / 100);
        else if(dau == 'B' && cuoi == 'Y') return Math.round(Tien() * 17 / 100);
        else return Math.round(Tien() * 22 / 100);
    }
    
    @Override
    public String toString()
    {
        return String.format("%s %.0f %.0f %.0f %.0f %.0f",ma,nhap,soLuongXuatHang(),donGia(),Tien(),Thue());
    }
}
