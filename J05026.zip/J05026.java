/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class J05026 {
    
    public static String chuanhoa(String s)
    {
        String res = "";
        String [] words = s.trim().toUpperCase().split("\\s+");
        for (String word : words)
        {
            res += word.charAt(0);
        }
        return res;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList <GiangVien> arr = new ArrayList <>();
        int t = Integer.parseInt(sc.nextLine());
        while(t-- >0) arr.add(new GiangVien(sc.nextLine(), sc.nextLine()));
        int q = Integer.parseInt(sc.nextLine());
        while(q-- >0)
        {   
            String s = sc.nextLine();
            s = chuanhoa(s);
            System.out.println("DANH SACH GIANG VIEN BO MON " + s + ":");
            for(GiangVien gv : arr)
            {
                if(gv.get_subject().compareTo(s) == 0) System.out.println(gv);
            }
        }
        
    }
}
//3
//Nguyen Manh Son
//Cong nghe phan mem
//Vu Hoai Nam
//Khoa hoc may tinh
//Dang Minh Tuan
//An toan thong tin
//1
//Cong nghe phan mem