/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class J05068 {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        ArrayList <DonHang> arr = new ArrayList <>();
        int t = Integer.parseInt(sc.nextLine());
        while(t-- >0)
        {
            arr.add(new DonHang(sc.nextLine()));
        }
        Collections.sort(arr);
        for(DonHang dh : arr)
        {
            System.out.println(dh);
        }
    }
}
//5
//N89BP 4500
//D00BP 3500
//X92SH 2600
//N89TN 4500
//D00TN 3500