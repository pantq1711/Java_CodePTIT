/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
public class HoaDon {
    
    private static int count = 0;
    private String ID;
    private KhachHang khachHang;
    private MatHang matHang;
    private int soLuong;

    public HoaDon(KhachHang khachHang, MatHang matHang, int soLuong) {
        this.ID = "HD" + String.format("%03d", ++count);
        this.khachHang = khachHang;
        this.matHang = matHang;
        this.soLuong = soLuong;
    }

   @Override
   public String toString()
   {
       return ID + " " + khachHang.getName() + " " + khachHang.getAddress() + " " + matHang.getName() + " " + matHang.getDonVi() + " " + matHang.getGiaMua() + " " + matHang.getGiaBan() + " " + soLuong + " " + matHang.getGiaBan() * soLuong;
   }
}
