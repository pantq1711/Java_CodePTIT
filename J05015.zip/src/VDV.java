import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class VDV implements Comparable<VDV> {
    
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("H:mm");
    
    LocalTime start_Time = LocalTime.of(6, 0);
    
    private String ten, donvi;
    
    private LocalTime end_Time;
    
    private int speed;

    public VDV(String ten, String donvi, String end_Time) {
        this.ten = ten;
        this.donvi = donvi;
        this.end_Time = LocalTime.parse(end_Time, dtf);
        speed = Math.round(120.0f * 3600.0f / getS());
    }
    
    public int getS() {
        return (int)Duration.between(start_Time, end_Time).getSeconds();
    }
    
    @Override
    public int compareTo(VDV o) {
        return this.end_Time.compareTo(o.end_Time);
    }
    
    public String chuanhoa() {
        String s = donvi + " " +  ten;
        String [] words = s.trim().split("\\s+");
        String res = "";
        for(String word : words) res += word.toUpperCase().charAt(0);
        return res;
    }
    
    @Override
    public String toString() {
        return chuanhoa() + " " + ten + " " + donvi + " " + speed + " Km/h";
    }
}
