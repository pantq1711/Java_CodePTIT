/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class J05015 {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        int t = Integer.parseInt(sc.nextLine());
        List <VDV> arr = new ArrayList <>();
        while(t-- >0) arr.add(new VDV(sc.nextLine(), sc.nextLine(), sc.nextLine()));
        Collections.sort(arr);
        for(VDV v : arr)
        {
            System.out.println(v);
        }
    }
}
//3
//Tran Vu Minh
//Ha Noi
//8:30
//Vu Ngoc Hoang
//Hoa Binh
//8:20
//Pham Dinh Tan
//An Giang
//8:45