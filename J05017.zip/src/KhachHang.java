/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class KhachHang implements Comparable <KhachHang> {
    
    public static int stt = 0;
    
    private String ID, ten;
    
    private int chisoCu, chisoMoi, chiso;

    public KhachHang(String ten, int chisoCu, int chisoMoi) {
        ID = String.format("KH%02d", ++stt);
        this.ten = ten;
        this.chisoCu = chisoCu;
        this.chisoMoi = chisoMoi;
        chiso = this.chisoMoi - this.chisoCu;
    }
    
    private static int getDonGia(int chiso)
    {
        if(chiso >= 0 && chiso <= 50) return 100;
        else if(chiso >= 51 && chiso <= 100) return 150;
        else return 200;
    }
    
    public static double getPhuPhi(int chiso)
    {
        if(chiso >= 0 && chiso <= 50) return 0.02;
        else if(chiso >= 51 && chiso <= 100) return 0.03;
        else return 0.05;
    }
    
    public int getTongTien()
    {
        int x = getDonGia(chiso);
        double y = getPhuPhi(chiso);
        if(chiso <= 50){
            return (int) Math.round(x * chiso * (1.0 + getPhuPhi(chiso)));
        }
        else if(chiso > 50 && chiso <= 100)
        {
            return (int)(Math.round((1.0 + getPhuPhi(chiso)) * (getDonGia(chiso) * (chiso - 50) +  getDonGia(50) * 50)));
        }
        else 
            return (int) Math.round((1.0 + getPhuPhi(chiso)) * (getDonGia(chiso) * (chiso - 100) + getDonGia(50) * 50 + getDonGia(100) * 50));
    }
    
    @Override
    public int compareTo(KhachHang o)
    {
        return o.getTongTien() - this.getTongTien();
    }
    
    @Override
    public String toString()
    {
        
        return String.format("%s %s %d", ID, ten, getTongTien());
    }
}
