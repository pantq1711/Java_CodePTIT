/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
public class J07007 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Set <String> set = new TreeSet<>();
        while(sc.hasNext()){
           set.add(sc.next());
        }
        for(String x : set){
            System.out.println(x);
        }
    }
}
//lap trinh Huong doi tuong
//lap trinh Huong thanh phan
