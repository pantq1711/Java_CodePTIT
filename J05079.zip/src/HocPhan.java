/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class HocPhan implements Comparable <HocPhan> {
    
    private String ID, nameSub, classID, nameTeacher;

    public HocPhan(String ID, String nameSub, String classID, String nameTeacher) {
        this.ID = ID;
        this.nameSub = nameSub;
        this.classID = classID;
        this.nameTeacher = nameTeacher;
    }

    public String getID() {
        return ID;
    }

    public String getNameSub() {
        return nameSub;
    }
    
    @Override
    public int compareTo(HocPhan o)
    {
        return Integer.parseInt(this.classID) - Integer.parseInt(o.classID);
    }
    
    @Override
    public String toString()
    {
        return classID + " " + nameTeacher;
    }
}
