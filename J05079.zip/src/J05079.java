/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class J05079 {
    
    public static void main(String[] args) {
        
        Map <String, HocPhan> map = new HashMap <>();
        Scanner sc = new Scanner(System.in);
        int t = Integer.parseInt(sc.nextLine());
        ArrayList <HocPhan> arr = new ArrayList <>();
        while(t-- >0)
        {
            HocPhan hp = new HocPhan(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine());
            arr.add(hp);
            map.put(hp.getID(), hp);
        }
        Collections.sort(arr);
        t = Integer.parseInt(sc.nextLine());
        while(t-- >0)
        {
            String s = sc.next();
            System.out.printf("Danh sach nhom lop mon %s:\n", map.get(s).getNameSub());
            for(HocPhan hp : arr)
            {
                if(hp.getID().equals(s)) System.out.println(hp);
            }
        }
    }
}
