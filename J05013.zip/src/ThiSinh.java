/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class ThiSinh implements Comparable <ThiSinh> {
    
    public static int stt = 0;
    
    private String ID, name;
    
    private double practicePoint, theoryPoint;
    
    private double avaragePoint;
    
    public static double solve(Double n)
    {
        if(n > 10) return n / 10;
        else return n;
    }

    public ThiSinh(String name, double practicePoint, double theoryPoint) {
        ID = String.format("TS%02d", ++stt);
        this.name = name;
        this.practicePoint = solve(practicePoint);
        this.theoryPoint = solve(theoryPoint);
        this.avaragePoint = (this.practicePoint + this.theoryPoint) / 2;
    }
    
    public String getStatus()
    {
        if(this.avaragePoint < 5) return "TRUOT";
        else if(this.avaragePoint >=  5 && this.avaragePoint < 8) return "CAN NHAC";
        else if(this.avaragePoint >= 8 && this.avaragePoint <= 9.5) return "DAT";
        else return "XUAT SAC";
    }
    
    @Override
    public int compareTo(ThiSinh o)
    {
        if(this.avaragePoint < o.avaragePoint) return 1;
        else return -1;
    }
    
    @Override
    public String toString()
    {
        return String.format("%s %s %.2f %s", ID, name, avaragePoint, getStatus());
    }
}
