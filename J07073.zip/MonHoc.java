/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class MonHoc implements Comparable<MonHoc>{
    
    private String ID, name;
    private int tin_chi;
    private String ly_thuyet, thuc_hanh;
    private boolean check;
    public MonHoc(String ID, String name, int tin_chi, String ly_thuyet, String thuc_hanh) {
        this.ID = ID;
        this.name = name;
        this.tin_chi = tin_chi;
        this.ly_thuyet = ly_thuyet;
        this.thuc_hanh = thuc_hanh;
        if(thuc_hanh.compareTo("Truc tuyen") == 0 || thuc_hanh.contains(".ptit.edu.vn"))  this.check = true;
        else this.check = false;
    }
    
    public boolean getcheck(){
        return this.check;
    }
    
    @Override
    public int compareTo(MonHoc o){
        return this.ID.compareTo(o.ID);
    }
    
    
    @Override
    public String toString(){
        return String.format("%s %s %d %s %s", this.ID, this.name, this.tin_chi, this.ly_thuyet, this.thuc_hanh);
    }
    
}
