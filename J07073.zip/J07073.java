/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
public class J07073 {
    
    public static void main(String[] args)throws FileNotFoundException{
        Scanner sc = new Scanner(new File("MONHOC.in"));
        ArrayList <MonHoc> arr = new ArrayList <>();
        int n = Integer.parseInt(sc.nextLine());
        while(n -- >0){
            arr.add(new MonHoc(sc.nextLine(), sc.nextLine(), Integer.parseInt(sc.nextLine()), sc.nextLine(), sc.nextLine()));
        }
        Collections.sort(arr);
        for(MonHoc mh: arr){
            if(mh.getcheck() == true) System.out.println(mh);
        }
    }
}
//3
//INT1306
//Cau truc du lieu va giai thuat
//3
//Truc tiep
//code.ptit.edu.vn
//INT13110
//Lap trinh mang voi C++
//3
//Truc tiep
//Truc tuyen
//INT1155
//Tin hoc co so 2
//2
//Truc tiep
//code.ptit.edu.vn