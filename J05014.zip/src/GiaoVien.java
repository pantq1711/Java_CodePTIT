/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
public class GiaoVien implements Comparable <GiaoVien> {
    
    public static int stt = 0;
    
    private String ma, name, ID;
    
    private double grade1, grade2, finalGrade;

    public GiaoVien(String name, String ID, double grade1, double grade2) {
        this.ma = String.format("%02d", ++stt);
        this.name = name;
        this.ID = ID;
        this.grade1 = grade1;
        this.grade2 = grade2;
        this.finalGrade = grade1 * 2 + grade2 + priority_Point();
    }
    
    public String getSubject()
    {
        char c = ID.charAt(0);
        if(c == 'A') return "TOAN";
        else if(c == 'B') return "LY";
        else return "HOA";
    }
    
    public double priority_Point()
    {
        char c = ID.charAt(1);
        if(c == '1') return 2.0;
        else if(c == '2') return 1.5;
        else if(c == '3') return 1.0;
        else return 0.0;
    }
    
    public String status()
    {
        if(this.finalGrade >= 18) return "TRUNG TUYEN";
        else return "LOAI";
    }
    
    @Override
    public int compareTo(GiaoVien o)
    {
        if(this.finalGrade < o.finalGrade) return 1;
        else if(this.finalGrade > o.finalGrade) return -1;
        else return this.ma.compareTo(o.ma);
    }
    
    @Override
    public String toString()
    {
        return "GV" + String.format("%s %s %s %.1f %s", ma, name, getSubject(), finalGrade, status());
    }
    
}