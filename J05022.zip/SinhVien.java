/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class SinhVien {
    
    private String ID, name, lop_hoc, email;

    public SinhVien(String ID, String name, String lop_hoc, String email) {
        this.ID = ID;
        this.name = name;
        this.lop_hoc = lop_hoc;
        this.email = email;
    }

    public String getlop_hoc() {
        return lop_hoc;
    }
    
    @Override
    public String toString()
    {
        return this.ID + " " + this.name + " " + this.lop_hoc + " " + this.email;
    }
}
