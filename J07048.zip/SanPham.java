/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class SanPham implements Comparable<SanPham> {
    private String ID, Name;
    private int Price_Sell, HSD;

    public SanPham(String ID, String Name, int Price_Sell, int HSD) {
        this.ID = ID;
        this.Name = Name;
        this.Price_Sell = Price_Sell;
        this.HSD = HSD;
    }
    @Override
    public int compareTo(SanPham o){
        if(this.Price_Sell == o.Price_Sell) return this.ID.compareTo(o.ID);
        return o.Price_Sell - this.Price_Sell;
    }
    @Override
    public String toString(){
        return this.ID + " " + this.Name + " " + this.Price_Sell + " " + this.HSD;
    }
}
