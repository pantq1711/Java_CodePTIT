/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.io.FileNotFoundException;
import java.io.File;
import java.util.*;
public class J07048 {
    public static void main(String[] args) throws FileNotFoundException{
        Scanner sc = new Scanner(new File("SANPHAM.in"));
        int t = Integer.parseInt(sc.nextLine());
        ArrayList <SanPham> arr = new ArrayList <>();
        for(int i=1; i<=t; ++i){
            arr.add(new SanPham(sc.nextLine(), sc.nextLine(), sc.nextInt(), sc.nextInt()));
            sc.nextLine();
        }
        Collections.sort(arr);
        for(SanPham sp : arr){
            System.out.println(sp);
        }
    }
}
//2
//KC740
//May khoan KC1
//39
//18
//KC742
//May cat KC2
//46
//12
