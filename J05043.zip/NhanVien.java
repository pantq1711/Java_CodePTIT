/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class NhanVien  {
    
    public static int cnt = 0;
    
    private String ID, ten;
    
    private int luong_ngay, so_ngay, phu_cap;
    
    private String chuc_vu;
    
    public int get_luong_thang()
    {
        return luong_ngay * so_ngay;
    }
    
    public int get_thu_nhap()
    {
        return get_luong_thang() + phu_cap;
    }
    
    public int get_tam_ung()
    {
        double tam_ung = (get_luong_thang() + phu_cap) ;
        tam_ung *=  2;
        tam_ung /= 3;
        if(tam_ung < 25000) return (int)Math.round(tam_ung/1000) * 1000;
        else return 25000;
    }
    

    public NhanVien(String ten, String chuc_vu, int luong_ngay, int so_ngay) {
        this.ID = String.format("NV%02d", ++cnt);
        this.ten = ten;
        this.luong_ngay = luong_ngay;
        this.so_ngay = so_ngay;
        this.chuc_vu = chuc_vu;
        switch(chuc_vu.charAt(0)){
            case 'G':
                this.phu_cap = 500;
                break;
            case 'P':
                this.phu_cap = 400;
                break;
            case 'T':
                this.phu_cap = 300;
                break;
            case 'K':
                this.phu_cap = 250;
                break;
            default :
                this.phu_cap = 100;
        }
    }
    
    @Override
    public String toString()
    {
        return this.ID + " " + this.ten + " " + this.phu_cap + " " + this.get_luong_thang() + " " + this.get_tam_ung() + " " + (this.get_thu_nhap() - this.get_tam_ung());
    }
}
