/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class DonHang {
    
    public String ID;
    
    public long soLuong;

    public DonHang(String ID) {
        String [] words = ID.trim().split("\\s+");
        this.ID = words[0];
        this.soLuong = Long.parseLong(words[1]);
    }
    
    public int donGia()
    {
        char c = ID.charAt(0);
        if(c == 'X') return 128000;
        else if(c == 'D') return 11200;
        else return 9700;
    }
    
    public String hangSanXuat()
    {
        switch(ID.substring(ID.length() - 2)){
            case "BP":
                return "British Petro";
            case "ES":
                return "Esso";
            case "SH":
                return "Shell";
            case "CA":
                return "Castrol";
            case "MO":
                return "Mobil";
            default:
                return "Trong Nuoc";               
        }
    }
    
    public double Thue()          
    {
        if(hangSanXuat() == "Trong Nuoc") return 0;
        else 
        switch(ID.charAt(0)){
            case 'X':
                return 0.03;
            case 'D':
                return 0.035;
            default :
                return 0.02;
        }
    }
    
    
    public long thanhTien()
    {
        return (long)(donGia() * soLuong * (1 + Thue()));
    }
    
    public String toString()
    {
        return ID + " " + hangSanXuat() + " " + donGia() + " " + (long)(Thue() * donGia() * soLuong) + " " + thanhTien();
    }
}
