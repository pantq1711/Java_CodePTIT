/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class CaThi implements Comparable<CaThi>{
    private String ID, Date, Time, Room;
    public CaThi(int ID, String Date, String Time, String Room) {
        this.ID = "C" + String.format("%03d", ID);
        this.Date = Date;
        this.Time = Time;
        this.Room = Room;
    }
    public int getseconds(){
        return Integer.parseInt(this.Time.substring(0, 2)) * 60 * 60 + Integer.parseInt(this.Time.substring(3)) * 60;
    }
    @Override
    public int compareTo(CaThi o){
        if (this.Date.compareTo(o.Date) == 0){
            if(this.getseconds() == o.getseconds()) return this.ID.compareTo(o.ID);
            return this.getseconds() - o.getseconds();
        }
        return this.Date.compareTo(o.Date);
    }
    @Override
    public String toString(){
        return this.ID + " " + this.Date + " " + this.Time + " " + this.Room;
    }
}
