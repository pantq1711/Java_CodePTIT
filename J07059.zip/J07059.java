/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
//import java.io.EOFException;
public class J07059 {
    public static void main(String[] args) throws FileNotFoundException{
        Scanner sc = new Scanner(new File("CATHI.in"));
        ArrayList <CaThi> arr = new ArrayList<>();
        int t = Integer.parseInt(sc.nextLine());
        for(int i=1; i<=t; ++i) arr.add(new CaThi(i, sc.nextLine(), sc.nextLine(), sc.nextLine()));
        Collections.sort(arr);
        for(CaThi ct : arr){
            System.out.println(ct);
        }
    }
}
//2
//09/01/2022
//15:30
//70172
//09/01/2022
//10:00
//70279
