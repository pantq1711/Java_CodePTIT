/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class MatHang implements Comparable<MatHang> {
    private String ID, Name, Group;
    private double Price_Sell, Price_Buy, Profit;

    public MatHang(int ID, String Name, String Group, double Price_Buy, double Price_Sell) {
        this.ID = "MH" + String.format("%02d", ID);
        this.Name = Name;
        this.Group = Group;
        this.Price_Sell = Price_Sell;
        this.Price_Buy = Price_Buy;
        this.Profit = Price_Sell - Price_Buy;
    }
    @Override
    public int compareTo(MatHang o){
        return (int)(o.Profit - this.Profit);
    }
    @Override
    public String toString(){
        return this.ID + " " + this.Name + " " + this.Group +" " + String.format("%.2f", this.Profit);
    }
}
