/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.io.FileNotFoundException;
import java.io.File;
import java.util.*;
public class J07050 {
    public static void main(String[] args) throws FileNotFoundException{
        Scanner sc = new Scanner(new File("MATHANG.in"));
        int t = Integer.parseInt(sc.nextLine());
        ArrayList <MatHang> arr = new ArrayList <>();
        for(int i=1; i<=t; ++i){
            arr.add(new MatHang(i,sc.nextLine(), sc.nextLine(), sc.nextDouble(), sc.nextDouble()));
            sc.nextLine();
        }
        Collections.sort(arr);
        for(MatHang mh : arr){
            System.out.println(mh);
        }
    }
}
//3
//May tinh SONY VAIO
//Dien tu
//16400
//17699
//Tu lanh Side by Side
//Dien lanh
//18300
//25999
//Banh Chocopie
//Tieu dung
//27.5
//37