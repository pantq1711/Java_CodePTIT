/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
public class WordSet {
    private TreeSet <String> s1 = new TreeSet<>();

    public WordSet(String filename) throws FileNotFoundException {
        Scanner sc = new Scanner(new File(filename));
        while(sc.hasNext()){
            String s = sc.next().toLowerCase();
            s1.add(s);
        }
    }

    public WordSet(TreeSet <String> res) {
        this.s1 = res;
    }
    
    
    public WordSet union(WordSet s)
    {
        TreeSet s2 = new TreeSet<>();
        s2.addAll(s.s1);
        s2.addAll(this.s1);
        return new WordSet(s2);
    }
    
    public WordSet intersection(WordSet s)
    {
        TreeSet s2 = new TreeSet <>();
        TreeSet s3 = new TreeSet <>();
        s3.addAll(s.s1);
        for(Object x : s3)
        {
            if(this.s1.contains(x)) s2.add(x);
        }
        return new WordSet(s2);
    }
    
    @Override
    public String toString()
    {
        String res = "";
        for(String x : this.s1)
        {
            res += x + " ";
        }
        return res.trim();
    }
}
