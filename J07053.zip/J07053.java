/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
public class J07053 {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("XETTUYEN.in"));
        ArrayList <Person> arr = new ArrayList <>();
        int t = Integer.parseInt(sc.nextLine());
        for(int i=1; i<=t; ++i){
            arr.add(new Person(i, sc.nextLine(), sc.nextLine(), Double.parseDouble(sc.nextLine()), Double.parseDouble(sc.nextLine())));
        }
        for(Person p : arr){
            System.out.println(p);
        }
    }
}
//3
//Doan Thi Kim
//13/03/1982
//8
//9.5
//dinh Thi NGOC HA
//3/9/1996
//6.5
//8
//  tran thanh mai
//12/9/2004
//8
//9