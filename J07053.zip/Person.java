/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import static java.lang.Math.round;
import java.util.*;
public class Person {
    private String ID, Name, Date;
    private double theory_Point, practice_Point;
    private double total_Point; 
    private long Point;
    private int years_Old;
    private String rank;
    public Person(int ID, String Name, String Date, double theory_Point, double practice_Point) {
        this.ID = "PH" + String.format("%02d", ID);
        this.Name = "";
        String [] words = Name.trim().split("\\s+");
        for(String word : words){
            this.Name += word.toUpperCase().charAt(0);
            for(int j = 1; j<word.length(); ++j) this.Name += word.toLowerCase().charAt(j);
            this.Name += " ";
        }
        this.Name = this.Name.trim();
        this.Date = Date;
        this.years_Old = 2021 - Integer.parseInt(Date.substring(Date.length() - 4));
        this.theory_Point = theory_Point;
        this.practice_Point = practice_Point;
        this.total_Point = (theory_Point + practice_Point) / 2;
        if(this.theory_Point >= 8 && this.practice_Point >= 8) this.total_Point += 1;
        else if(this.theory_Point >= 7.5 && this.practice_Point >= 7.5) this.total_Point += 0.5;
        this.Point = Math.round(this.total_Point);
        if(this.Point > 10) this.Point = 10;
        if(this.Point < 5) this.rank = "Truot";
        else if(this.Point == 5 || this.Point == 6) this.rank = "Trung binh";
        else if(this.Point == 7) this.rank = "Kha";
        else if(this.Point == 8) this.rank = "Gioi";
        else this.rank = "Xuat sac";
    }
    @Override
    public String toString(){
        return this.ID + " " + this.Name + " " + this.years_Old + " " + this.Point + " " + this.rank;
    }
}
