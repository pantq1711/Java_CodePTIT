/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai10;

/**
 *
 * @author Anphan
 */
public class SinhVien implements Comparable <SinhVien> {
    
    private String ten, line;
    
    private int ac, sub;

    public SinhVien(String ten, String line) {
        this.ten = ten;
        this.line = line;
        String [] words = line.split(" ");
        ac = Integer.parseInt(words[0]);
        sub = Integer.parseInt(words[1]);
    }
    
    @Override
    public int compareTo(SinhVien o)
    {
        if(this.ac == o.ac)
        {
            if(this.sub == o.sub) return this.ten.compareTo(o.ten);
            else return this.sub - o.sub;
        }
        return o.ac - this.ac;
    }
    
    @Override
    public String toString()
    {
        return ten + " " + line;
    }
}
