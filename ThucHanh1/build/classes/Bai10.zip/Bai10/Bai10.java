/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai10;

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
public class Bai10 {
    
    public static void main(String[] args) throws FileNotFoundException{
        
        Scanner sc = new Scanner(new File("LUYENTAP.in"));
        int t = Integer.parseInt(sc.nextLine());
        List <SinhVien> arr = new ArrayList <>();
        while(t-- >0)
        {
            arr.add(new SinhVien(sc.nextLine(), sc.nextLine()));
        }
        Collections.sort(arr);
        for(SinhVien sv : arr)
        {
            System.out.println(sv);
        }
    }
}
