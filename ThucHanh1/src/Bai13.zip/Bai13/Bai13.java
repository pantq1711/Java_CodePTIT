/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai13;

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
public class Bai13 {
    
    public static void main(String[] args) throws FileNotFoundException {
        
        Scanner sc = new Scanner(new File("MONHOC.in"));
        Map <String, Integer> map = new HashMap <>();
        List <MonHoc> arr = new ArrayList <>();
        while(sc.hasNextLine())
        {
            MonHoc mh = new MonHoc(sc.nextLine(), sc.nextLine(), sc.nextLine());
            if(map.containsKey(mh.getID())) map.put(mh.getID(), map.get(mh.getID()) + 1);
            else map.put(mh.getID(), 1);
            if(map.get(mh.getID()) == 1) arr.add(mh);           
        }
        Collections.sort(arr);
        for(MonHoc mh : arr)
        {
            System.out.println(mh);
        }
    }
}
