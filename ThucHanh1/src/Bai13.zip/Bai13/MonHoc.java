/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai13;

/**
 *
 * @author Anphan
 */
public class MonHoc implements Comparable <MonHoc> {
    
    private String ID, name, HT;

    public MonHoc(String ID, String name, String HT) {
        this.ID = ID;
        this.name = name;
        this.HT = HT;
    }
    
    public String getID()
    {
        return ID;
    }
    
    @Override
    public int compareTo(MonHoc o)
    {
        return this.ID.compareTo(o.ID);
    }
    
    @Override
    public String toString()
    {
        return ID + " " + name + " " + HT;
    }
}
