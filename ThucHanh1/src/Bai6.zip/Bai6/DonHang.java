/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai6;

/**
 *
 * @author Anphan
 */
public class DonHang {
    
    public String ten, ID;
    
    public double d, s;

    public DonHang(String ten, String ID, double d, double s) {
        this.ten = ten;
        this.ID = ID;
        this.d = d;
        this.s = s;
    }
    
    public String id()
    {
        return ID.substring((ID.length()-1));
    }
    
    public String stt(){
        return ID.substring(1,4);
    }
    
    public double gg()
    {
        if(id().charAt(0) == '2') return Math.round(d * s * 3 / 10);
        else return Math.round(d *s / 2);
    }
    
    public double tien()
    {
        return d * s - gg();
    }
    
    @Override
    public String toString(){
        return String.format("%s %s %s %.0f %.0f", ten, ID, stt(), gg(), tien());
    }
}
