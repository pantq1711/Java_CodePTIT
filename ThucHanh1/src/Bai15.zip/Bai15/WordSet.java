/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai15;

/**
 *
 * @author Anphan
 */
import java.util.*;
public class WordSet {
    
    private Set <String> set;
    
    private String s;

    public WordSet(String s) {
        String [] words = s.toLowerCase().trim().split("\\s+");
        ArrayList <String> arr = new ArrayList <>();
        for(String word : words) arr.add(word);
        set = new TreeSet <>(arr);
    }
    
    public WordSet(ArrayList <String> arr)
    {
        this.set = new TreeSet <>(arr);
    }
    
    public WordSet union(WordSet a)
    {
        ArrayList <String> arr = new ArrayList <>();
        for(String word : a.set) arr.add(word);
        for(String word : this.set) arr.add(word);
        return new WordSet(arr);
    }
    
    public WordSet intersection(WordSet a)
    {
        ArrayList <String> arr1 = new ArrayList <>();
        ArrayList <String> arr2 = new ArrayList <>();
        for(String word : a.set) arr1.add(word);
        for(String word : this.set) if(arr1.contains(word)) arr2.add(word);
        return new WordSet(arr2);
    }
    
    @Override
    public String toString()
    {
        String res = "";
        for(String word : set) res += word.toLowerCase() + " ";
        return res.trim();
    }
}
