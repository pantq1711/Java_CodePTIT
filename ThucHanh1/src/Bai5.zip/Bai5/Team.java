/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai5;

/**
 *
 * @author Anphan
 */
public class Team {
    
    private String nameT, nameC;

    public Team(String nameT, String nameC) {
        this.nameT = nameT;
        this.nameC = nameC;
    }

    public String getNameT() {
        return nameT;
    }

    public String getNameC() {
        return nameC;
    }
    
}
