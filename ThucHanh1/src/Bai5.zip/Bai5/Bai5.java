/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai5;

/**
 *
 * @author Anphan
 */
import java.util.*;
public class Bai5 {
    
    public static void main(String[] args) {
        
        Map <Integer, Team> map = new HashMap <>();
        Scanner sc = new Scanner(System.in);
        List <Team> arr = new ArrayList <>();
        int t = Integer.parseInt(sc.nextLine());
        int l = 0;
        for(int i=0; i<t; ++i)
        {
            Team T = new Team(sc.nextLine(), sc.nextLine());
            arr.add(T);
            map.put(++l, T);
        }
        List <SinhVien> arr2 = new ArrayList <>();
        t = Integer.parseInt(sc.nextLine());
        while(t-- >0)
        {
            SinhVien sv = new SinhVien(sc.nextLine(), sc.nextLine());
            sv.setTN_CN(map.get(sv.getSTT_Team()).getNameC(), map.get(sv.getSTT_Team()).getNameT());
            arr2.add(sv);
        }
        Collections.sort(arr2);
        for(SinhVien sv : arr2)
        {
            System.out.println(sv);
        }
    }
}
//2
//BAV_MIS
//Banking Academy of Vietnam
//FTU Knights1
//Foreign Trade University
//6
//Le Trung Toan
//Team01
//Nguyen Trinh Quoc Long
//Team01
//Giang Minh Tung
//Team01
//Nguyen Hang Giang
//Team02
//Nguyen Thanh Nhan
//Team02
//Nguyen Viet Duc
//Team02