/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai5;

/**
 *
 * @author Anphan
 */
import java.util.*;
public class SinhVien implements Comparable <SinhVien> {
    
    public static int stt = 0;
    
    private String ID, name, idTeam, teamName, collegeName;

    public SinhVien(String name, String teamName) {
        ID = String.format("C%03d", ++stt);
        this.name = name;
        this.idTeam = teamName;
    }
    
    public int getSTT_Team()
    {
        return Integer.parseInt(idTeam.substring(idTeam.length() - 2));
    }
    
    public void setTN_CN(String n, String m)
    {
        teamName = n;
        collegeName = m;
    }
    
    
    @Override
    public int compareTo(SinhVien o)
    {
        return this.name.compareTo(o.name);
    }
    
    @Override
    public String toString()
    {
        return ID + " " + name + " " + collegeName + " " + teamName;  
    }
}
