/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class DonHang implements Comparable <DonHang> {
    
    public String ten, ID;
    
    public double donGia, soLuong;

    public DonHang(String ten, String ID, double donGia, double soLuong) {
        this.ten = ten;
        this.ID = ID;
        this.donGia = donGia;
        this.soLuong = soLuong;
    }
    
    public String maLoai(){
        return ID.substring(ID.length() - 1);
    }
    
    public String stt(){
        return ID.substring(1, 4);
    }
    
    public double giamGia(){
        if(maLoai().charAt(0) == '1') return Math.round(donGia * soLuong / 2);
        else return Math.round(donGia * soLuong * 3 / 10);
    }
    
    public double thanhTien()
    {
        return donGia * soLuong - giamGia();
    }
    
    @Override
    public int compareTo(DonHang o)
    {
        return this.stt().compareTo(o.stt());
    }
    
    @Override
    public String toString()
    {
        return String.format("%s %s %s %.0f %.0f", ten, ID, stt(), giamGia(), thanhTien());
    }
}
