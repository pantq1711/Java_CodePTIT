import java.util.ArrayList;
import java.util.Scanner;
public class J05008 {
    
    public static double calculateArea(ArrayList<Point> points) {
        int n = points.size();
        double area = 0;
        for (int i = 0; i < n; i++) {
            Point currentPoint = points.get(i);
            Point nextPoint = points.get((i + 1) % n); // Lấy đỉnh tiếp theo, xem x[i+1] = x[0]
            area += (currentPoint.x * nextPoint.y - currentPoint.y * nextPoint.x);
        }

        return Math.abs(area) / 2.0; // Trả về diện tích dương
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while (t-- > 0) {
            int n = sc.nextInt();
            ArrayList<Point> points = new ArrayList<>();

            for (int i = 0; i < n; i++) {
                points.add(new Point(sc.nextDouble(), sc.nextDouble()));
            }

            double area = calculateArea(points);
            System.out.printf("%.3f\n", area);
        }
    }
}
