/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.text.DecimalFormat;
import java.util.*;
public class DonHang {
    DecimalFormat df = new DecimalFormat("0.00");
    
    private String ID;
    
    private int price, quantity;

    public DonHang(String line) {
        String [] words = line.trim().split("\\s");
        this.ID = words[0];
        this.price = Integer.parseInt(words[1]);
        this.quantity = Integer.parseInt(words[2]);
    }
    
    public double getFee()
    {
        switch(ID.charAt(0))
        {
            case 'T':
                return 0.04;
        case 'C':
            return 0.03;
        case 'D':
            return 0.025;
        default:
            return 0.005;
    }
}
public double getTax()
{
    double res = 1;
    if(ID.charAt(ID.length() - 1) == 'C') res -= 0.05;
    switch(ID.charAt(0))
    {
        case 'T':
            return res * 0.29;
        case 'C':
            return res * 0.1;
        case 'D':
            return res * 0.08;
        default:
            return res * 0.02;
    }
}
public double getTotalMoney() {
        return price * quantity * (1.0 + getTax() + getFee()) / quantity * 1.2;
    }
    @Override
    public String toString() {
        String formattedTotalMoney = df.format(getTotalMoney());
        return ID + " " + formattedTotalMoney;
    }

}
