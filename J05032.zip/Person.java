/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.temporal.ChronoUnit;
public class Person implements Comparable <Person> {
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    
    private String name;
    
    private Date date_Of_Birth;

    
    public Person(String s) throws ParseException{
        String [] words = s.trim().split("\\s+");
        this.name = words[0];
        this.date_Of_Birth = sdf.parse(words[1]);
    }
    
    public long get_Ngay(){
        Date current_Date = new Date();
        return ChronoUnit.DAYS.between(this.date_Of_Birth.toInstant(), current_Date.toInstant());
    }
    
    @Override
    public int compareTo(Person o)
    {
        return (int)(this.get_Ngay() - o.get_Ngay());
    }
    
    @Override
    public String toString()
    {
        return this.name;
    }
}
