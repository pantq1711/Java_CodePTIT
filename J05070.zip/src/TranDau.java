/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
public class TranDau implements Comparable <TranDau> {
    
    public String ID, ten;
    
    public int soLuong, doanhThu;

    public TranDau(String s) {
        String [] words = s.trim().split("\\s+");
        this.ID = words[0];
        this.soLuong = Integer.parseInt(words[1]);
    }

    public String getID() {
        return ID.substring(1, 3);
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }
    
    public void setDoanhThu(int n)
    {
        doanhThu += n;
    }
    
    @Override
    public int compareTo(TranDau o)
    {
        if(this.doanhThu == o.doanhThu) return this.ten.compareTo(o.ten);
        else return o.doanhThu - this.doanhThu;
    }
    
    @Override
    public String toString()
    {
        return ID + " " + ten + " " + doanhThu;
    }
}
