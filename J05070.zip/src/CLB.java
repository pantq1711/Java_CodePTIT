/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
public class CLB {
   
    public String ID, ten;
    
    public int giaVe;

    public CLB(String ID, String ten, int giaVe) {
        this.ID = ID;
        this.ten = ten;
        this.giaVe = giaVe;
    }

    public String getID() {
        return ID;
    }

    public String getTen() {
        return ten;
    }

    public int getGiaVe() {
        return giaVe;
    }
    
    @Override
    public String toString()
    {
        return ten;
    }
}
