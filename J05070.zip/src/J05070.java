/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class J05070 {
    
    public static void main(String[] args) {
        
        Map <String, CLB> map = new HashMap<>();
        Scanner sc = new Scanner(System.in);
        int t = Integer.parseInt(sc.nextLine());
        ArrayList <CLB> arr = new ArrayList <>();
        for(int i=0; i<t; ++i){
            CLB a = new CLB(sc.nextLine(), sc.nextLine(), Integer.parseInt(sc.nextLine()));
            arr.add(a);
            map.put(a.getID(), a);
        }
        t = Integer.parseInt(sc.nextLine());
        ArrayList <TranDau> arr2 = new ArrayList <>();
        for(int i=0; i<t; ++i)
        {
            TranDau a = new TranDau(sc.nextLine());
            arr2.add(a);
            if(map.containsKey(a.getID())){
                arr2.get(i).setDoanhThu(arr2.get(i).getSoLuong() * map.get(arr2.get(i).getID()).getGiaVe());
                arr2.get(i).setTen(map.get(arr2.get(i).getID()).getTen());
            }
        }
        Collections.sort(arr2);
        for(TranDau td : arr2){
            System.out.println(td);
        }
    }
}