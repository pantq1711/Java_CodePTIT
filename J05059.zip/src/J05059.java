
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class J05059 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        ArrayList <ThiSinh> arr = new ArrayList<>();
        int t = Integer.parseInt(sc.nextLine());
        for(int i=1; i<=t; ++i) arr.add(new ThiSinh(sc.nextLine(), sc.nextLine(), Double.parseDouble(sc.nextLine()), Double.parseDouble(sc.nextLine()), Double.parseDouble(sc.nextLine())));
        int chiTieu = Integer.parseInt(sc.nextLine());
        Collections.sort(arr);
        if(chiTieu > arr.size()) chiTieu = arr.size();
        double diemChuan = arr.get(chiTieu-1).getToTal_Point();
        System.out.printf("%.1f\n", diemChuan);
        for(ThiSinh ts : arr){
            if(ts.getToTal_Point() >= diemChuan){
                ts.setStatus("TRUNG TUYEN");
            }
            else ts.setStatus("TRUOT");
            System.out.println(ts);
        }
    }
}
