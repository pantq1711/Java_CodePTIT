/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class DanhSach implements Comparable<DanhSach>{
    
    private String full_Name, first_Name, last_Name;

    public DanhSach(String full_Name) {
        this.full_Name = full_Name;
        String [] words = full_Name.trim().split("\\s+");
        this.first_Name = words[words.length-1];
        this.last_Name = full_Name.substring(0, this.full_Name.length() - this.first_Name.length());
    }
    
    public String getfull_Name(){
        return this.full_Name;
    }
    
    @Override
    public int compareTo(DanhSach o){
        if(this.first_Name.compareTo(o.first_Name) == 0){
            return this.last_Name.compareTo(o.last_Name);
        }
        return this.first_Name.compareTo(o.first_Name);
    }
    
    @Override
    public String toString(){
        return this.full_Name;
    }
}
