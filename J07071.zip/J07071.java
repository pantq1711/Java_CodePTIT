/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
public class J07071 {
    public static String viet_Tat(String s){
        String res = "";
        String [] words = s.trim().split("\\s+");
        for(String word : words) res += word.charAt(0);
        return res;
    }
    
    public static void main(String[] args) throws FileNotFoundException{
        Scanner sc = new Scanner(new File("DANHSACH.in"));
        ArrayList <DanhSach> arr = new ArrayList <>();
        
        int n = Integer.parseInt(sc.nextLine());
        while(n -- >0){
            arr.add(new DanhSach(sc.nextLine()));
        }
        
        Collections.sort(arr);
        
        int t = Integer.parseInt(sc.nextLine());
        while(t-- >0){
            String s = sc.nextLine();
            String tmp = "";
            for(int i=0; i<s.length(); ++i) if(s.charAt(i) != '.') tmp += s.charAt(i);
            boolean check;
            
            for(DanhSach ds : arr){
                check = true;
                String test = viet_Tat(ds.getfull_Name());
                int length = test.length();
                if(tmp.length() != length) continue;
                for(int i=0; i<tmp.length(); ++i){
                    if(tmp.charAt(i) != test.charAt(i) && tmp.charAt(i) != '*'){
                          check = false;
                          continue;
                        }
                }
                if(check == true) System.out.println(ds);
            }
        }
    }
}
//4
//Nguyen Manh Son
//Ngo Minh Tuan
//Nguyen Manh Hung
//Tran Trung Dung
//2
//N.H.*
//T.*.D