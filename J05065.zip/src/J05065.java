import java.util.*;
public class J05065 {
   
    public static void main(String[] args) {
        
        Map <String, Integer> map = new HashMap <>();
        Scanner sc = new Scanner(System.in);
        ArrayList <NhanVien> arr = new ArrayList <>();
        int t = Integer.parseInt(sc.nextLine());
        while(t-- >0){
            NhanVien nv = new NhanVien( sc.nextLine());
            arr.add(nv);
            String tmp = nv.chucVu;
            if(map.containsKey(tmp)){
            map.put(tmp, map.get(tmp) + 1);
        }
        else map.put(tmp, 1);
        nv.solve(map.get(tmp));
        }
        Collections.sort(arr);
       t = Integer.parseInt(sc.nextLine());

        for (int i = 0; i < t; ++i) {
            String s = sc.nextLine();
            for (NhanVien nv : arr) {   
                if (nv.chucVu.equals(s)) {
                    System.out.print(nv);
                }
            }
            System.out.println();
        }
    }
}