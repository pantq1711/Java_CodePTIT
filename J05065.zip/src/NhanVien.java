import java.util.*;
public class NhanVien implements Comparable <NhanVien> {
    
    public String ID, name, chucVu, heSoLuong;
    
    public NhanVien(String s) {
    String[] parts = s.trim().split("\\s+");
    if (parts.length >= 2) {
        String ID = parts[0];
        name = s.substring(ID.length()).trim();
        this.heSoLuong = ID.substring(2, 4);
        this.ID = ID.substring(4);
        chucVu = ID.substring(0, 2);
    } 
}

    public void setChucVu(String s)
    {
        chucVu = s;
    }
    
    
    public void solve(int n)
    {
        if(chucVu.compareTo("GD") == 0 && n > 1) setChucVu("NV");
        else if((chucVu.compareTo("TP") == 0 || chucVu.compareTo("PP") == 0) && n > 3) setChucVu("NV");
    }
    
    @Override
    public int compareTo(NhanVien o)
    {
        if(this.heSoLuong.compareTo(o.heSoLuong) == 0) return this.ID.compareTo(o.ID);
        else return o.heSoLuong.compareTo(this.heSoLuong);
    }
    
    @Override
    public String toString()
    {
        return String.format("%s %s %s %s\n", name, chucVu, ID, heSoLuong);
    }
}
