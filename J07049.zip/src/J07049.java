import java.util.*;
import java.io.*;
public class J07049 {
    
    public static void main(String[] args) throws FileNotFoundException {
        
        Scanner sc = new Scanner(new File("MUAHANG.in"));
        int t = Integer.parseInt(sc.nextLine());
        Map <String, SanPham> map = new HashMap <>();
        while(t-- >0)
        {
            SanPham sp = new SanPham(sc.nextLine(), sc.nextLine(), Integer.parseInt(sc.nextLine()), Integer.parseInt(sc.nextLine()));
            map.put(sp.getID(), sp);
        }
        t = Integer.parseInt(sc.nextLine());
        ArrayList <KhachHang> arr = new ArrayList <>();
        while(t-- >0)
        {
            KhachHang kh = new KhachHang(sc.nextLine(), sc.nextLine(), sc.nextLine(), Integer.parseInt(sc.nextLine()), sc.nextLine());
            kh.setDate(map.get(kh.getIDSP()).getMonths());
            kh.setPrice(map.get(kh.getIDSP()).getPrice());
            arr.add(kh);
        }
        Collections.sort(arr);
        for(KhachHang kh : arr)
        {
            System.out.println(kh);
        }
    }
}