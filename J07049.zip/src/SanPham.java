public class SanPham {
 
    private String IDSP, name;
    
    private int price, countMonths;

    public SanPham(String ID, String name, int price, int countMonths) {
        this.IDSP = ID;
        this.name = name;
        this.price = price;
        this.countMonths = countMonths;
    }
    
    public int getMonths(){
        return this.countMonths;
    }
    
    public int getPrice()
    {
        return price;
    }
    
    public String getID(){
        return IDSP;
    }
}

