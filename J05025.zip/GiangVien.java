/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class GiangVien implements Comparable <GiangVien> {
    
    public static int cnt = 0;
    
    private String ID, name, subject;

    public GiangVien(String name, String subject) {
        this.ID = String.format("GV%02d", ++cnt);
        this.name = name;
        this.subject = subject;
    }
    
    public String chuanhoa(String s)
    {
        String res = "";
        String [] words = s.trim().toUpperCase().split("\\s+");
        for (String word : words)
        {
            res += word.charAt(0);
        }
        return res;
    }
    
    public String getTen()
    {
        String res = "";
        String [] words = name.trim().toUpperCase().split("\\s+");
        return words[words.length - 1];
    }
    
    @Override
    public int compareTo(GiangVien o)
    {
        if(this.getTen().compareTo(o.getTen()) == 0) return this.ID.compareTo(o.ID);
        return this.getTen().compareTo(o.getTen());
    }
    
    @Override
    public String toString()
    {
        return this.ID + " " + this.name + " " + this.chuanhoa(subject);
    }
}