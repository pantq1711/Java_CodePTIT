/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.time.LocalDate;
import java.text.ParseException;
import java.time.format.DateTimeFormatter;
public class Person implements Comparable <Person> {
    
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    
    LocalDate curDate = LocalDate.of(2021,1,1);
    
    public static int cnt = 0;
    
    public String ID, name;
    
    public LocalDate dateOfBirth;
    
    public double practicePoint, theoryPoint;

    public Person(String name, String dateOfBirth, double practicePoint, double theoryPoint) throws ParseException{
        this.ID = String.format("PH%02d", ++cnt);
        this.name = name;
        this.dateOfBirth = LocalDate.parse(dateOfBirth, dtf);
        this.practicePoint = practicePoint;
        this.theoryPoint = theoryPoint;
    }
    
    public long getYearsOld(){
        return curDate.getYear() - dateOfBirth.getYear();
    }
    
    public double bonusPoint()
    {
        if(practicePoint >= 8 && theoryPoint >= 8) return 1;
        else if(practicePoint >= 7.5 && theoryPoint >= 7.5) return 0.5;
        else return 0;
    }
    
    public double totalPoint()
    {
        double res = Math.round(bonusPoint() + (practicePoint + theoryPoint) / 2);
        if (res > 10) res = 10;
        return res;
    }
    
    public String rank()
    {
        double p = totalPoint();
        if(p < 5) return "Truot";
        else if(p <= 6) return "Trung binh";
        else if(p == 7) return "Kha";
        else if(p == 8) return "Gioi";
        else return "Xuat sac";
    }
    
    @Override
    public int compareTo(Person o)
    {
        if(totalPoint() < o.totalPoint()) return 1;
        else if(totalPoint() > o.totalPoint()) return -1;
        else return this.ID.compareTo(o.ID);
    }
    
    @Override
    public String toString()
    {
        return String.format("%s %s %d %.0f %s", ID, name, getYearsOld(), totalPoint(), rank());
    }
}
