
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author Anphan
 */
public class J07038 {

    public static void main(String[] args) throws FileNotFoundException {

        Scanner sc = new Scanner(new File("SINHVIEN.in"));
        int t = Integer.parseInt(sc.nextLine());
        Map<String, SinhVien> map1 = new HashMap<>();
        while (t-- > 0) {
            SinhVien sv = new SinhVien(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine());
            map1.put(sv.getID(), sv);
        }

        Map<String, Dn> map2 = new HashMap<>();
        sc = new Scanner(new File("DN.in"));
        t = Integer.parseInt(sc.nextLine());
        while(t-- >0) {
            Dn d = new Dn(sc.nextLine(), sc.nextLine(), Integer.parseInt(sc.nextLine()));
            map2.put(d.getID(), d);
        }
        ArrayList<SinhVien> res = new ArrayList<>();
        sc = new Scanner(new File("THUCTAP.in"));
        t = Integer.parseInt(sc.nextLine());
        ArrayList<String> arr = new ArrayList<>();
        while (t-- > 0) {
            String[] words = sc.nextLine().trim().split("\\s+");
            String IDSV = words[0], IDDN = words[1];
            if (map1.containsKey(IDSV)) {
                SinhVien sv = map1.get(IDSV);
                sv.setCheck();
                sv.setIDDN(IDDN);
                map2.get(IDDN).setSLSV();
                res.add(sv);
            }
        }
        Collections.sort(res);
        t = Integer.parseInt(sc.nextLine());
        while (t-- > 0) {
            String s = sc.nextLine();
            int SL = map2.get(s).getQuantity();
            int N = map2.get(s).getSLSV();
            System.out.println("DANH SACH THUC TAP TAI " + map2.get(s).getName() + ":");
            if(N > SL) N = SL;
            ArrayList <SinhVien> tmp = new ArrayList <>();
            for(SinhVien sv : res)
            {
                if(sv.getIDDN().equals(s))
                tmp.add(sv);
            }
            for(int i=0; i<N; ++i)
            {
                System.out.println(tmp.get(i));
            }
        }
    }
}
