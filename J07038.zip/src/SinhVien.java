

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
public class SinhVien implements Comparable<SinhVien>{
    
    public static String chuanhoa(String n)
    {
        String res = "";
        String [] words = n.trim().split("\\s+");
        for(String word : words) res += word.toUpperCase().charAt(0) + word.toLowerCase().substring(1) + " ";
        return res.trim();
    }    
    private String ID, name, className, email, nameDN;
    
    private boolean check;

    public SinhVien(String ID, String name, String className, String email) 
    {
            this.ID = ID;
            this.name = chuanhoa(name);
            this.className = className;
            this.email = email;
            this.check = false;
            this.nameDN = "";
    }
    
    public String getIDDN()
    {
        return this.nameDN;
    }
    
    public void setIDDN(String n)
    {
        this.nameDN = n;
    }
    public void setCheck()
    {
        check = true;
    }
    public String getID()
    {
        return ID;
    }
    
    @Override
    public int compareTo(SinhVien o)
    {
        return this.ID.compareTo(o.ID);
    }
    
    @Override
    public String toString()
    {
        return ID + " " + name + " " + className;
    }
}
