/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
public class Dn {
    
    private String ID, name;
        
        private int quantity, SLSV;
        
        public Dn(String ID, String name, int quantity)
        {
            this.ID = ID;
            this.name = name;
            this.quantity = quantity;
            this.SLSV = 0;
        }
        
        public void setSLSV()
        {
            ++SLSV;
        }
        
        public int getSLSV()
        {
            return SLSV;
        }
        
        public int getQuantity()
        {
            return quantity;
        }
        
        public void setQuantity(int n)
        {
            quantity = n;
        }
        public String getID()
        {
            return ID;
        }
        
        public String getName()
        {
            return this.name;
        }
        
}
