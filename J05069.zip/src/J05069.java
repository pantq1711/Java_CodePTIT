import java.util.*;

public class J05069 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int t = Integer.parseInt(sc.nextLine());
        Map<String, DoiBong> map = new HashMap<>();
        ArrayList<DoiBong> arr1 = new ArrayList<>();
        for (int i = 0; i < t; ++i) {
            DoiBong a = new DoiBong(sc.nextLine(), sc.nextLine(), Integer.parseInt(sc.nextLine()));
            arr1.add(a);
            map.put(a.getMaCLB(), a);
        }

        ArrayList<TranDau> arr2 = new ArrayList<>();
        int q = Integer.parseInt(sc.nextLine());
        for (int i = 0; i < q; ++i) {
            TranDau a = new TranDau(sc.nextLine());
            arr2.add(a);
            String maCLB = a.getID();
            if (map.containsKey(maCLB)) {
                int doanhthu = a.getSoLuong() * map.get(maCLB).getGiaVe();
                a.setDoanhThu(doanhthu);
            }
        }
        for (int i = 0; i < arr2.size(); ++i) {
            System.out.println(arr2.get(i) + " " + map.get(arr2.get(i).getID())+ " " + arr2.get(i).getDoanhThu());
        }
    }
}

//2
//AC
//AC Milan
//12
//MU
//Manchester United
//10
//2
//IAC1 80000
//EMU2 60000