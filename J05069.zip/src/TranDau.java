/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
public class TranDau {
    
    public String ID;
    
    public int soLuong, doanhThu;

    public TranDau(String s) {
        String [] words = s.trim().split("\\s+");
        this.ID = words[0];
        this.soLuong = Integer.parseInt(words[1]);
    }
    
    public void setDoanhThu(int n)
    {
        doanhThu += n;
    }
    
    public int getDoanhThu()
    {
        return doanhThu;
    }
    public int getSoLuong()
    {
        return soLuong;
    }
    
    public String getID()
    {
        return ID.substring(1, 3);
    }
 
    @Override
    public String toString(){
        return ID;
    }
}
