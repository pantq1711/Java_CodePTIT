/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
public class DoiBong {
    
    public String ID, ten;
    
    public int giaVe;

    public DoiBong(String ID, String ten, int giaVe) {
        this.ID = ID;
        this.ten = ten;
        this.giaVe = giaVe;
    }
    
    public String getMaCLB()
    {
        return ID;
    }
    
    public int getGiaVe()
    {
        return giaVe;
    }
    
    @Override
    public String toString()
    {
        return ten;
    }
}
