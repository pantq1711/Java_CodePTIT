import java.util.*;
public class SinhVien implements Comparable <SinhVien> {
    
    private String ID, name, Class, Email;

    public SinhVien(String ID, String name, String Class, String Email) {
        this.ID = ID;
        this.name = name;
        this.Class = Class;
        this.Email = Email;
    }
    
    @Override
    public int compareTo(SinhVien o)
    {
        return this.ID.compareTo(o.ID);
    }
    
    @Override
    public String toString()
    {
        return this.ID + " " + this.name + " " + this.Class + " " + this.Email;
    }
}