import java.util.*;
import java.time.*;
import java.time.format.DateTimeFormatter;

public class J05019 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int t = Integer.parseInt(sc.nextLine());
        Map<String, TramDo> map = new LinkedHashMap<>();

        while (t-- > 0) {
            TramDo td = new TramDo(sc.nextLine(), sc.nextLine(), sc.nextLine(), Integer.parseInt(sc.nextLine()));

            if (map.containsKey(td.getTen())) {
                // Nếu đã có trong map, cập nhật thông tin
                TramDo existingTramDo = map.get(td.getTen());
                existingTramDo.setLuongMua(td.getLuongMua());
                existingTramDo.setThoiGian(td.getThoiGian());
            } else {
                // Nếu chưa có trong map, thêm vào map
                map.put(td.getTen(), td);
            }
        }

        for (Map.Entry<String, TramDo> entry : map.entrySet()) {
            System.out.println(entry.getValue() +  String.format("%.2f", (double)entry.getValue().getLuongMua() / entry.getValue().getThoiGian() * 60));
        }
    }
}

class TramDo {

    public static int stt = 0;

    private String ID, ten;

    private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm");

    private LocalTime startTime, endTime;

    private int luongmua, thoigian;

    public TramDo(String ten, String startTime, String endTime, int luongmua) {
        this.ID = String.format("T%02d", ++stt);
        this.ten = ten;
        this.startTime = LocalTime.parse(startTime, dtf);
        this.endTime = LocalTime.parse(endTime, dtf);
        this.luongmua = luongmua;
        this.thoigian = (int) Duration.between(this.startTime, this.endTime).toMinutes();
    }

    public String getTen() {
        return ten;
    }

    public int getLuongMua() {
        return luongmua;
    }

    public int getThoiGian() {
        return thoigian;
    }

    public void setLuongMua(int n) {
        luongmua += n;
    }

    public void setThoiGian(int n) {
        thoigian += n;
    }

    @Override
    public String toString() {
        return ID + " " + ten + " ";
    }
}
