/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
public class TramDo {

    public static int stt = 0;

    private String ID, ten;

    private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm");

    private LocalTime startTime, endTime;

    private int luongmua, thoigian;

    public TramDo(String ten, String startTime, String endTime, int luongmua) {
        this.ID = String.format("T%02d", ++stt);
        this.ten = ten;
        this.startTime = LocalTime.parse(startTime, dtf);
        this.endTime = LocalTime.parse(endTime, dtf);
        this.luongmua = luongmua;
        this.thoigian = (int) Duration.between(this.startTime, this.endTime).toMinutes();
    }

    public String getTen() {
        return ten;
    }

    public int getLuongMua() {
        return luongmua;
    }

    public int getThoiGian() {
        return thoigian;
    }

    public void setLuongMua(int n) {
        luongmua += n;
    }

    public void setThoiGian(int n) {
        thoigian += n;
    }

    @Override
    public String toString() {
        return ID + " " + ten + " ";
    }
}
