import java.util.*;

public class LoHang {

    public static Map<String, Integer> map = new LinkedHashMap<>();

    public static int cnt = 0;

    public String ID, ten;

    public int so_luong, don_gia;

    public static String viet_tat(String s) {
        String res = "";
        String[] words = s.trim().split("\\s+");
        for (int i = 0; i < words.length && i < 2; i++) {
            res += words[i].toUpperCase().charAt(0);
        }
        return res;
    }

    public LoHang(String ten, int so_luong, int don_gia) {
        this.ten = ten;
        this.so_luong = so_luong;
        this.don_gia = don_gia;
        if (map.containsKey(viet_tat(ten))) {
            map.put(viet_tat(ten), map.get(viet_tat(ten)) + 1);
        } else {
            map.put(viet_tat(ten), 1);
        }
        this.ID = viet_tat(ten) + String.format("%02d", map.get(viet_tat(ten)));
    }

    public double getPhanTramChietKhau() {
        if (so_luong > 10) {
            return 0.05;
        } else if (so_luong >= 8) {
            return 0.02;
        } else if (so_luong >= 5) {
            return 0.01;
        } else {
            return 0;
        }
    }

    public int getSoTienChietKhau() {
        return (int) (don_gia * so_luong * getPhanTramChietKhau());
    }

    @Override
    public String toString() {
        return this.ID + " " + this.ten + " " + this.getSoTienChietKhau() + " "
                + (so_luong * don_gia - this.getSoTienChietKhau());
    }
}
