import java.text.ParseException;
import java.util.*;
public class Main{
    public static void main(String[] args) throws ParseException {
        
        Map <String, String> GD = new HashMap  <>();
        Map <String, GiaoDichVang> GDV = new HashMap <>();
        Map <String, GiaoDichTienTe> GDTT = new HashMap<>();
        ArrayList <String> arr1 = new ArrayList <>();
        Scanner sc = new Scanner(System.in);
        while(true)
        {
            System.out.println("===== MENU =====");
            System.out.println("1. Them giao dich vang");
            System.out.println("2. Them giao dich tien te");
            System.out.println("3. Hien thi danh sach giao dich");
            System.out.println("4. Xem tong so luong giao dich");
            System.out.println("5. Hien thi danh sach giao dich theo ngay");
            System.out.println("6. Hien thi danh sach giao dich co chua ngay");
            System.out.println("7. Hien thi danh sach giao dich theo tu nam den nam");
            System.out.println("0. Thoat");
            System.out.print("Chon mot chuc nang (0-7): ");
            int n = Integer.parseInt(sc.nextLine());
            switch(n)
            {
                case 1:
                    GiaoDichVang gdv = new GiaoDichVang(sc.nextLine(), sc.nextLine(), Integer.parseInt(sc.nextLine()), Integer.parseInt(sc.nextLine()), sc.nextLine());
                    GD.put(gdv.getNgay_V(), gdv.getID_V());
                    arr1.add(gdv.getNgay_V());
                    GDV.put(gdv.getID_V(), gdv);
                    break;
                case 2:
                    GiaoDichTienTe gdtt = new GiaoDichTienTe(sc.nextLine(), sc.nextLine(), Integer.parseInt(sc.nextLine()), Integer.parseInt(sc.nextLine()), Double.parseDouble(sc.nextLine()), sc.nextLine());
                    GD.put(gdtt.getNgay_TT(), gdtt.getID_TT());
                    arr1.add(gdtt.getNgay_TT());
                    GDTT.put(gdtt.getID_TT(), gdtt);
                case 3:
                    for(String x : arr1)
                    {
                        if(GDV.containsKey(GD.get(x)));
                        System.out.println(GDV.get(GD.get(x)));
                        if(GDTT.containsKey(GD.get(x)));
                        System.out.println(GDTT.get(GD.get(x)));
                    }
                    break;
                case 4 :
                    System.out.println(arr1.size());
                    break;
                case 5:
                    ArrayList <String> tmp = (ArrayList<String>) arr1.clone();
                    Collections.sort(tmp);
                    for(String x : tmp)
                    {
                        if(GDV.containsKey(GD.get(x)));
                        System.out.println(GDV.get(GD.get(x)));
                        if(GDTT.containsKey(GD.get(x)));
                        System.out.println(GDTT.get(GD.get(x)));                        
                    }
                    break;
                case 6:
                    System.out.println("Moi ban nhap ngay dd/mm/yyyy");
                    String ngay = sc.nextLine();
                    for(String x : arr1)
                    {
                        if(x.equals(ngay))
                        {
                        if(GDV.containsKey(GD.get(x)))
                        {
                            System.out.println(GDV.get(GD.get(x)));
                        }
                        if(GDTT.containsKey(GD.get(x)))
                        {
                            System.out.println(GDTT.get(GD.get(x))); 
                        }                            
                        }
                    }
                    break;
                case 7:
                    System.out.println("Moi ban nhap nam den nam");
                    int start = sc.nextInt(), end = sc.nextInt();
                    for(String x : arr1)
                    {
                        int nam = Integer.parseInt(x.substring(6));
                        if(nam >= start && nam <= end)
                        {
                        if(GDV.containsKey(GD.get(x)))
                        {
                            System.out.println(GDV.get(GD.get(x)));
                        }
                        if(GDTT.containsKey(GD.get(x)))
                        {
                            System.out.println(GDTT.get(GD.get(x)));                             
                        }
                        }                     
                    }
                    break;
                case 0:
                    System.exit(0);
            }
        }
        
        
    }
}