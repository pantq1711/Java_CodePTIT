/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.io.FileNotFoundException;
import java.io.File;
public class J07056 {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("KHACHHANG.in"));
        ArrayList <KhachHang> arr = new ArrayList<>();
        int n = Integer.parseInt(sc.nextLine());
        for(int i=1; i<=n; ++i){
            arr.add(new KhachHang(i, sc.nextLine(), sc.nextLine()));
        }
        Collections.sort(arr);
        for(KhachHang kh : arr){
            System.out.println(kh);
        }
    }
}
//2
// nGuyEn Hong Ngat
//C 200 278
// Chu thi    minh
//A 120 160