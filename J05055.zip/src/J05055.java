/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class J05055 {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        int t = Integer.parseInt(sc.nextLine());
        ArrayList <Person> arr = new ArrayList <>();
        while(t-- >0)
        {
            arr.add(new Person(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine()));
        }
        ArrayList <Person> tmp = (ArrayList<Person>) arr.clone();
        Collections.sort(tmp);
        tmp.get(0).setrank(1);
        for(int i=1; i<tmp.size(); ++i){
            if(tmp.get(i).calculateFinalTime().getSeconds() == tmp.get(i - 1).calculateFinalTime().getSeconds()) tmp.get(i).setrank(tmp.get(i - 1).getrank());
            else tmp.get(i).setrank(i + 1);
        }
        for(Person p : arr){
            System.out.println(p);
        }
    }
}
//6
//Nguyen Van Thanh
//20/03/1990
//07:00:00
//07:10:01
//Nguyen Hoa Binh
//01/10/1993
//07:02:00
//07:11:20
//Le Thanh Van
//15/03/1998
//07:05:00
//07:15:30
//Nguyen Thanh
//20/03/1990
//07:00:00
//07:10:01
//Van Thanh
//20/03/1990
//07:00:00
//07:10:01
//Nguyen Van
//20/03/1990
//07:00:00
//07:10:01
