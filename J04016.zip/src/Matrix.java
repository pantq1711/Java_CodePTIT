/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class Matrix {
    
    private int n, m;
    
    private int [][] a;

    public Matrix(int n, int m) {
        this.a  = new int[n][m];
        this.n = n;
        this.m = m;
    }
    
    public void nextMatrix(Scanner sc)
    {
        for(int i=0; i<n; ++i)
        {
            for(int j=0; j<m; ++j) a[i][j] = sc.nextInt();
        }
    }
    
    public Matrix mul(Matrix b)
    {
        int p = b.m;
        Matrix res = new Matrix(n, p);
        for(int i=0; i<n; ++i)
        {
            for(int j=0; j<p; ++j)
            {
                res.a[i][j] = 0;
                for(int k=0; k<m; ++k) res.a[i][j] += a[i][k] * b.a[k][j];
            }
        }
        return res;
    }
    
    @Override
    public String toString()
    {
        String res = "";
        for(int i=0; i<n; ++i)
        {
            for(int j=0; j<m; ++j) res += Integer.toString(a[i][j]) + " ";
            res += "\n";
        }
        return res;
    }
}
