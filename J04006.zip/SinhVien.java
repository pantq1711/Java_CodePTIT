package J04006;
import java.util.*;
public class SinhVien{
    Scanner sc = new Scanner(System.in);
    private String ID, name, date, Class;
    private double gpa;
    public SinhVien(){
        this.ID = "B20DCCN001";
        this.name = sc.nextLine();
        this.Class = sc.nextLine();
        this.date = sc.nextLine();
        this.gpa = sc.nextDouble();
    }
    public String chuanhoadate(){
        StringBuilder sb = new StringBuilder(date);
        if(sb.charAt(1) == '/') sb.insert(0, '0');
        if(sb.charAt(4) == '/') sb.insert(3, '0');
        return sb.toString();
    }
    public void in(){
        date = chuanhoadate();
        System.out.print(ID + " " + name + " " + Class + " " + date + " ");
        System.out.printf("%.2f", gpa);
    }
}