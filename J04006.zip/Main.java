import java.util.*;

import J04006.SinhVien;
public class Main{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SinhVien y = new SinhVien();
        y.in();
    }
}
// Nguyen Hoa Binh
// D20CQCN04-B
// 2/2/2002
// 2
