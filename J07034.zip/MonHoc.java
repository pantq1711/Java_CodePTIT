/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
public class MonHoc implements Comparable <MonHoc>{
    private String ID, Name;
    private int Quantity;

    public MonHoc(String ID, String Name, int Quantity) {
        this.ID = ID;
        this.Name = Name;
        this.Quantity = Quantity;
    }


    @Override
    public int compareTo(MonHoc o) {
        return this.Name.compareTo(o.Name);
    }
    @Override
    public String toString() {
        return this.ID + " " + this.Name + " " + this.Quantity;
    }
}
