/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class NhanVien {
    
    public static int cnt = 0;
    
    private String ID, name, sex, date_Of_Birth, address, num_Of_Fax, date_Of_Contracts;

    public NhanVien(String name, String sex, String date_Of_Birth, String address, String num_Of_Fax, String date_Of_Contracts) {
        this.ID = String.format("000%02d", ++cnt);
        this.name = name;
        this.sex = sex;
        this.date_Of_Birth = date_Of_Birth;
        this.address = address;
        this.num_Of_Fax = num_Of_Fax;
        this.date_Of_Contracts = date_Of_Contracts;
    }
    
    @Override
    public String toString()
    {
        return this.ID + " " + this.name + " " + this.sex + " " + this.date_Of_Birth + " " + this.address + " " + this.num_Of_Fax + " " + this.date_Of_Contracts;
    }
}
