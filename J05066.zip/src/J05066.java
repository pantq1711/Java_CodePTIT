import java.util.*;
public class J05066 {
   
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        ArrayList <NhanVien> arr = new ArrayList <>();
        int t = Integer.parseInt(sc.nextLine());
        while(t-- >0){
            NhanVien nv = new NhanVien(sc.nextLine());
            nv.solve();
            arr.add(nv);

        }
        Collections.sort(arr);
        t = Integer.parseInt(sc.nextLine());
        for(int i=0; i<t; ++i)
        {
            String s = sc.nextLine();
            for(NhanVien nv : arr)
            {   
                if(nv.name.toLowerCase().contains(s.toLowerCase())) System.out.print(nv);
            }
            System.out.println();
        }
    }
}
// 6
// GD08001 Nguyen Kim Loan
// TP05002 Hoang Thanh Tuan
// TP05001 Tran Binh Nguyen
// PP06002 Phan Trung Tuan
// PP06001 Tran Quoc Huy
// NV04003 Vo Van Lan
// 2
// OA
// aN