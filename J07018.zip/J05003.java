/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.io.*;
import java.text.ParseException;

public class J05003 {
    public static void main(String[] args)throws FileNotFoundException, ParseException {
        Scanner sc = new Scanner(new File("SINHVIEN.in"));
        ArrayList <SinhVien> arr = new ArrayList<>();
        int t = Integer.parseInt(sc.nextLine());
        while(t-- >0){
            arr.add(new SinhVien(sc.nextLine(), sc.nextLine(), sc.nextLine(), Double.parseDouble(sc.nextLine())));
        }
        for(SinhVien sv : arr){
            System.out.println(sv);
        }
    }
}
//1
//Nguyen Van An
//D20CQCN01-B
//2/2/2002
//3.19