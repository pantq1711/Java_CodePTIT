/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
public class SinhVien {
    
    public String ID, ten, lop;
    
    public int diem;

    public SinhVien(String ID, String ten, String lop) {
        this.ID = ID;
        this.ten = ten;
        this.lop = lop;
    }
    
    public String status()
    {
        if(diem == 0) return " KDDK";
        else return "";
    }
    
    public String getID()
    {
        return ID;
    }

    public void setDiem(int diem) {
        this.diem = diem;
    }

    public String getLop() {
        return lop;
    }
    
    @Override
    public String toString()
    {
        return ID + " " + ten + " " + lop + " " + diem + status();
    }
}
