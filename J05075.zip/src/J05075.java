/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class J05075 {
    
    public static int diemcc(String s)
    {
        int res = 10;
        for(int i=0; i<s.length(); ++i)
        {
            if(s.charAt(i) == 'm') res -= 1;
            else if(s.charAt(i) == 'v') res -= 2;
            else continue;
        }
        return res < 0 ? 0 : res;
    }
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        int t = Integer.parseInt(sc.nextLine());
        ArrayList <SinhVien> arr = new ArrayList <>();
        for(int i=0; i<t; ++i) arr.add(new SinhVien(sc.nextLine(), sc.nextLine(), sc.nextLine()));
        Map <String, Integer> map = new HashMap<>();
        for(int i=0; i<t; ++i){
            String s = sc.nextLine();
            String [] words = s.trim().split("\\s+");
            map.put(words[0], diemcc(words[1]));
        }
        String s = sc.nextLine();
        for(SinhVien sv : arr)
        {
            if(map.containsKey(sv.getID())){
                sv.setDiem(map.get(sv.getID()));
            }
            if(s.compareTo(sv.getLop()) == 0)
            System.out.println(sv);
        }
    }
}
//3
//B19DCCN999
//Le Cong Minh
//D19CQAT02-B
//B19DCCN998
//Tran Truong Giang
//D19CQAT02-B
//B19DCCN997
//Nguyen Tuan Anh
//D19CQCN04-B
//B19DCCN998 xxxmxmmvmx
//B19DCCN997 xmxmxxxvxx
//B19DCCN999 xvxmxmmvvm
