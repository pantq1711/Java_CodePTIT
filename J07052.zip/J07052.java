/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
public class J07052 {
    public static void main(String[] args) throws FileNotFoundException{
        Scanner sc = new Scanner(new File("THISINH.in"));
        ArrayList <ThiSinh> arr = new ArrayList<>();
        int t = Integer.parseInt(sc.nextLine());
        for(int i=1; i<=t; ++i) arr.add(new ThiSinh(sc.nextLine(), sc.nextLine(), Double.parseDouble(sc.nextLine()), Double.parseDouble(sc.nextLine()), Double.parseDouble(sc.nextLine())));
        int chiTieu = Integer.parseInt(sc.nextLine());
        Collections.sort(arr);
        if(chiTieu > arr.size()) chiTieu = arr.size();
        double diemChuan = arr.get(chiTieu-1).getToTal_Point();
        System.out.printf("%.1f\n", diemChuan);
        for(ThiSinh ts : arr){
            if(ts.getToTal_Point() >= diemChuan){
                ts.setStatus("TRUNG TUYEN");
            }
            else ts.setStatus("TRUOT");
            System.out.println(ts);
        }
    }
}
//2
//KV2A002
//Hoang THAnh tuan
//5
//6
//5
//KV3B123
// LY Thi   THU ha
//8
//6.5
//7
//1