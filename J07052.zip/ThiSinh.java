/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.text.DecimalFormat;
public class ThiSinh implements Comparable<ThiSinh> {
    private String ID, Name;
    private double Grade_Math, Grade_Physics, Grade_Chemistry;
    private double Priority_Point;
    private double Total_Point;
    private int Quantity;
    private String status;
    public ThiSinh(String ID, String Name, double Grade_Math, double Grade_Physics, double Grade_Chemistry) {
        this.ID = ID;
        this.Name = "";
        String [] words = Name.trim().split("\\s+");
        for(String word : words){
            this.Name += word.toUpperCase().charAt(0);
            for(int j=1; j<word.length(); ++j) this.Name += word.toLowerCase().charAt(j);
            this.Name += " ";
        }
        this.Name = this.Name.trim();
        switch(ID.charAt(2)){
            case '1':
                this.Priority_Point = 0.5;
                break;
            case '2':
                this.Priority_Point = 1.0;
                break;
            default:
                this.Priority_Point = 2.5;
        }
        this.Grade_Math = Grade_Math;
        this.Grade_Physics = Grade_Physics;
        this.Grade_Chemistry = Grade_Chemistry;
        this.Total_Point = this.Grade_Math * 2 + this.Grade_Physics + this.Grade_Chemistry + this.Priority_Point;
    }
    public void setStatus(String status){
        this.status = status;
    }
    public double getToTal_Point(){
        return this.Total_Point;
    }
    @Override
    public int compareTo(ThiSinh o)
    {
       if (this.Total_Point < o.Total_Point)
           return 1;
       else if (this.Total_Point > o.Total_Point)
           return -1;
       return this.ID.compareTo(o.ID);
    }
    @Override
    public String toString(){
        return this.ID + " " + this.Name + " " + (new DecimalFormat().format(this.Priority_Point)) + " " + (new DecimalFormat().format(this.Total_Point))  + " " + this.status;
    }
}
