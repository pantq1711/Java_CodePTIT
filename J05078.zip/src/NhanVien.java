/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
public class NhanVien {
    
    public String ID, name_NV, name_CTY ;
    
    public int luongCoBan, soNgay;

    public NhanVien(String ID, String name, int luongCoBan, int soNgay) {
        this.ID = ID;
        this.name_NV = name;
        this.luongCoBan = luongCoBan * 1000;
        this.soNgay = soNgay;
    }
    
    public String getID_NV(){
        return ID.substring(3);
    }
    
    public int namCongTac(){
        return Integer.parseInt(ID.substring(1, 3));
    }
    
    public static int heSoNhan(int x, int y, int z, int t, int n){
        if(n > 16){
            return t;
        }
        else if(n >= 9 && n <= 15) return z;
        else if(n >= 4 && n <= 8) return y;
        else return x;
}
    
    public int heSoLuong()
    {
        int n = namCongTac();
        switch(ID.charAt(0))
        {
            case 'A':
                return heSoNhan(10, 12, 14, 20, n);
            case 'B':
                return heSoNhan(10, 11, 13, 16, n);
            case 'C':
                return heSoNhan(9, 10, 12, 14, n);
            default :
                return heSoNhan(8, 9, 11, 13, n);
                
        }
    }
    
    public long luongThang()
    {
        return 1L * luongCoBan * heSoLuong() * soNgay;
    }
    
    public void setName(String n)
    {
        this.name_CTY = n;
    }
    
    @Override
    public String toString()
    {
        return ID + " " + name_NV + " "  + luongThang(); 
    }
}
