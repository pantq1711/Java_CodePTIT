/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class LoaiPhong implements Comparable <LoaiPhong>{
    private String loai_Phong;
    private Character ID;
    private String Name;
    private double Price, Fee;

    public LoaiPhong(String loai_Phong) {
        this.loai_Phong = loai_Phong;
        String [] words = loai_Phong.trim().split("\\s+");
        this.ID = words[0].charAt(0);
        this.Name = words[1];
        this.Price = Double.parseDouble(words[2]);
        this.Fee = Double.parseDouble(words[3]);
    }
    @Override
    public int compareTo(LoaiPhong o){
        return this.Name.compareTo(o.Name);
    }
    @Override
    public String toString(){
        return this.loai_Phong;
    }
}
