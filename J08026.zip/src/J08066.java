import java.util.*;

public class J08066
{   
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        int t = Integer.parseInt(sc.nextLine());
        while(t-- >0)
        {
            int S = sc.nextInt(), T = sc.nextInt();
            Set <Integer> set = new HashSet <>();
            Queue <Pair> q = new LinkedList <>();
            q.add(new Pair(S, 0));
            while(!q.isEmpty())
            {
                Pair top = q.poll();
                int first = top.getFirst(), second = top.getSecond();
                if(first == T)
                {
                    System.out.println(second);
                    break;
                }
                if(first > 1 && !set.contains(first - 1))
                {
                    set.add(first - 1);
                    q.add(new Pair(first - 1, second + 1));
                }
                if(first < T && !set.contains(first * 2))
                {
                    set.add(first * 2);
                    q.add(new Pair(first * 2, second + 1));
                }
            }
        }
    }
}