import java.util.*;
public class Triangle{
    private double w, h;
    private String color;
    Triangle(double m, double n, String s){
        this.w = m;
        this.h = n;
        this.color = s.substring(0,1).toUpperCase() + s.substring(1).toLowerCase();
    }
    public double GetS(){
        return this.w * this.h;
    }
    public double GetC(){
        return (this.w + this.h) * 2;
    }
    public boolean check(){
        w = (int) this.w;
        h = (int) this.h;
        if(w <= 0 || h <= 0) return false;
        return true;
    }
    public void display(){
        if(check() == false) System.out.print("INVALID");
        else System.out.printf("%d %d %s", (int) this.GetC(), (int) this.GetS(), this.color);
    }
}