import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Triangle a = new Triangle(sc.nextDouble(), sc.nextDouble(), sc.next());
        a.display();
    }
}
