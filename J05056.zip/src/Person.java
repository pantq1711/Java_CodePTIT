import java.util.*;
import java.time.format.DateTimeFormatter;
import java.time.*;
public class Person implements Comparable <Person> {
    
    LocalDate ld = LocalDate.of(2021,1,1);
    
    LocalTime timeStart, timeEnd;
    
    DateTimeFormatter time = DateTimeFormatter.ofPattern("HH:mm:ss");
    
    DateTimeFormatter tuoi = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    
    public static int stt = 0;
    
    private LocalDate ngaySinh;
    
    private String ID, ten; 
            
    private LocalTime timeXuatPhat, timeDenDich;
    
    private int rank;
    
    private Duration final_time;
    
    private String ThanhTich, finalTime, uuTien;
    
    public Person(String ten, String ngaySinh, String timeXuatPhat, String timeDenDich) {
        this.ID = String.format("VDV%02d", ++stt);
        this.ten = ten;
        this.ngaySinh = LocalDate.parse(ngaySinh, tuoi);
        this.timeXuatPhat = LocalTime.parse(timeXuatPhat, time);
        this.timeDenDich = LocalTime.parse(timeDenDich, time);
        this.ThanhTich = formatDuration(calculateThanhTich());
        this.uuTien = formatDuration(calculateUuTien());
        this.finalTime = formatDuration(calculateFinalTime());
    }
    
    public Duration calculateUuTien()
    {
        int age = (int)(ld.getYear() - ngaySinh.getYear());
        if(age < 18) return Duration.ZERO;
        else if(age < 25) return Duration.ofSeconds(1);
        else if(age < 32) return Duration.ofSeconds(2);
        else return Duration.ofSeconds(3);
    }
    
    public Duration calculateThanhTich()
    {
        return Duration.between(timeXuatPhat, timeDenDich);
    }
    
    public Duration calculateFinalTime()
    {
        return calculateThanhTich().minus(calculateUuTien());
    }
    
    @Override
    public int compareTo(Person o)
    {
        return (int)(this.calculateFinalTime().getSeconds() - o.calculateFinalTime().getSeconds());
    }
    
    public static String formatDuration(Duration d){
        long h = d.toHours();
        long m = d.minusHours(h).toMinutes();
        long s = d.minusHours(h).minusMinutes(m).getSeconds();
        return String.format("%02d:%02d:%02d", h, m , s);
    }
    
    public int getrank(){
        return rank;
    }
    
    public void setrank(int n){
        this.rank = n;
    }
    
    
    @Override
    public String toString()
    {
        return String.format("%s %s %s %s %s %d", ID, ten, ThanhTich, uuTien, finalTime, getrank());
    }
}
