import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
class SinhVien {
    private String ma, ten, lop, date_Of_Birth;
    private float gpa;
    public SinhVien(int id, String ten, String lop, String date_Of_Birth, float gpa) throws ParseException {
        this.ma = "B20DCCN" + String.format("%03d", id);
        this.ten = ten;
        this.lop = lop;
        if(this.date_Of_Birth.charAt(1) == '/') this.date_Of_Birth = "0" + this.date_Of_Birth;
        if(this.date_Of_Birth.charAt(4) == '/') this.date_Of_Birth = this.date_Of_Birth.substring(0,3) + "0" + this.date_Of_Birth.substring(3);
        this.gpa = gpa;
    }
    @Override
    public String toString(){
        return ma + " " +  ten + " " + lop + " " + this.date_Of_Birth + " " + String.format("%.2f", gpa);
    }
}