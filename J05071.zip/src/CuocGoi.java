/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.time.*;
import java.time.format.DateTimeFormatter;
public class CuocGoi {
    
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm");
    
    private String SDT, cityLocation;
    
    LocalTime startTime, endTime;

    public CuocGoi(String line) {
        String [] words = line.trim().split("\\s+");
        this.SDT = words[0];
        this.startTime = LocalTime.parse(words[1], dtf);
        this.endTime = LocalTime.parse(words[2], dtf);
    }
    
    public String getIDCity()
    {
        return SDT.substring(0, 3);
    }
    
    public int getTime()
    {
        double res = (double)Duration.between(startTime, endTime).toMinutes();
        if(SDT.charAt(0) != '0')
        return (int) Math.round(res / 3);
        else return (int) res;
    }
    
    public void setCityLocation(String n)
    {
        this.cityLocation = n;
    }
    
    @Override
    public String toString()
    {
        return String.format("%s %s %d", SDT, this.cityLocation, getTime());
    }
}
