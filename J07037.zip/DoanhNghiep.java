/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class DoanhNghiep implements Comparable<DoanhNghiep> {
    private String ID, Name;
    private int Quantity;

    public DoanhNghiep(String ID, String Name, int Quantity) {
        this.ID = ID;
        this.Name = Name;
        this.Quantity = Quantity;
    }
    @Override
    public int compareTo(DoanhNghiep o){
        return this.ID.compareTo(o.ID);
    }
    @Override
    public String toString(){
        return this.ID + " " + this.Name + " " + this.Quantity;
    }
}
