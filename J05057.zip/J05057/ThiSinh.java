/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class ThiSinh {
    private String ID, name;
    
    private double diem_Toan, diem_Ly, diem_Hoa, tong_Diem;

    public static String chuanhoa(String s){
        String res = "";
        String words [] = s.trim().split("\\s+");
        for(String word : words) res += word.toUpperCase().charAt(0) + word.toLowerCase().substring(1) + " ";
        return res.trim();
    }
    
    public double getdiem_cong(){
        char c = this.ID.charAt(2);
        if(c == '1') return 0.5;
        else if(c == '2') return 1.0;
        else return 2.5;
    }
    
    public ThiSinh(String ID, String name, double diem_Toan, double diem_Ly, double diem_Hoa) {
        this.ID = ID;
        this.name = chuanhoa(name);
        this.diem_Toan = diem_Toan;
        this.diem_Ly = diem_Ly;
        this.diem_Hoa = diem_Hoa;
        this.tong_Diem = this.diem_Toan * 2 + this.diem_Hoa + this.diem_Ly;
    }
    
    
    public String get_Status(){
        if(this.tong_Diem + this.getdiem_cong() >= 24) return "TRUNG TUYEN";
        else return "TRUOT";
    }
    
    @Override
    public String toString(){
        String res = "";
        res += ID + " " + name + " ";
        if(this.getdiem_cong() != (int)this.getdiem_cong())
        res += String.format("%.1f ", this.getdiem_cong());
        else res += String.format("%d ", (int) getdiem_cong());
        if(tong_Diem != (int) tong_Diem) 
        res += String.format("%.1f ", tong_Diem);
        else res += String.format("%d ", (int) tong_Diem);
        res += get_Status();
        return res;   
    }
}
