/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class J05027 {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList <GiangVien> arr = new ArrayList <>();
        int t = Integer.parseInt(sc.nextLine());
        while(t-- >0) arr.add(new GiangVien(sc.nextLine(), sc.nextLine()));
        int q = Integer.parseInt(sc.nextLine());
        while(q-- >0)
        {   
            String s = sc.nextLine();
            System.out.println("DANH SACH GIANG VIEN THEO TU KHOA " + s + ":");
            for(GiangVien gv : arr)
            {
                if(gv.getName_toLowerCase().contains(s.toLowerCase())) System.out.println(gv);
            }
        }
        
    }
}
//3
//Nguyen Manh Son
//Cong nghe phan mem
//Vu Hoai Nam
//Khoa hoc may tinh
//Dang Minh Tuan
//An toan thong tin
//1
//aN