/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class SinhVien implements Comparable <SinhVien> {
    
    private String ID, name, phoneNums;
    
    private int stt;
    
    private String nameSub;

    public SinhVien(String ID, String name, String phoneNums, int stt) {
        this.ID = ID;
        this.name = name;
        this.phoneNums = phoneNums;
        this.stt = stt;
    }
    
    public void setNameSub(String n, int a, int b)
    {
        if(a == b)
        nameSub = String.format("%s", n);
    }

    public String nameSub()
    {
        return nameSub;
    }
    public int getStt() {
        return stt;
    }
    
    @Override
    public int compareTo(SinhVien o)
    {
        return this.ID.compareTo(o.ID);
    }
    
    @Override
    public String toString()
    {
        return ID + " " + name + " " + phoneNums + " " + stt + " " +  nameSub;
    }
}
