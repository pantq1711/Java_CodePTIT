/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class J05080 {
    
    public static void main(String[] args) {
       
        Scanner sc = new Scanner(System.in);
        int t = Integer.parseInt(sc.nextLine());
        ArrayList <HocPhan> arr = new ArrayList <>();
        while(t-- >0)
        {
            HocPhan hp = new HocPhan(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine());
            arr.add(hp);
        }
        Collections.sort(arr);
        t = Integer.parseInt(sc.nextLine());
        while(t-- >0)
        {
            String s = sc.nextLine();
            System.out.printf("Danh sach cho giang vien %s:\n", s);
            for(HocPhan hp : arr)
            {
                if(hp.getNameTeacher().equals(s)) System.out.println(hp);
            }
        }
    }
}
//4
//THCS2D20
//Tin hoc co so 2 - D20
//01
//Nguyen Binh An
//CPPD20
//Ngon ngu lap trinh C++ - D20
//01
//Le Van Cong
//THCS2D20
//Tin hoc co so 2 - D20
//02
//Nguyen Trung Binh
//LTHDTD19
//Lap trinh huong doi tuong - D19
//01
//Nguyen Binh An
//1
//Nguyen Binh An