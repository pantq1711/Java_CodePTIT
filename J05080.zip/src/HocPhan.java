/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class HocPhan implements Comparable <HocPhan> {
    
    private String ID, nameSub, classID, nameTeacher;

    public HocPhan(String ID, String nameSub, String classID, String nameTeacher) {
        this.ID = ID;
        this.nameSub = nameSub;
        this.classID = classID;
        this.nameTeacher = nameTeacher;
    }

    public String getNameTeacher() {
        return nameTeacher;
    }
    
    @Override
    public int compareTo(HocPhan o)
    {
        if(this.ID.equals(o.ID))
        return Integer.parseInt(this.classID) - Integer.parseInt(o.classID);
        else return this.ID.compareTo(o.ID);
    }
    
    @Override
    public String toString()
    {
        return ID + " " + nameSub + " " + classID;
    }
}
