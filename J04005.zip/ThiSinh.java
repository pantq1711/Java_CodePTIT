import java.util.*;
public class ThiSinh{
    Scanner sc = new Scanner(System.in);
    private String name, date;
    private float diem1, diem2, diem3, res;
    public ThiSinh(){
        this.name = sc.nextLine();
        this.date = sc.nextLine();
        this.diem1 = sc.nextFloat();
        this.diem2 = sc.nextFloat();
        this.diem3 = sc.nextFloat();
        this.res = diem1 + diem2 + diem3;
    }
    public void in(){
        System.out.print(name + " " + date + " ");
        System.out.printf("%.1f", res);
    }
}