/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class MatHang implements Comparable <MatHang> {
    
    public static int cnt = 0;
    
    private int ID;
    
    private String name, nhom;
    
    private double gia_mua, gia_ban, loi_nhuan;
    

    public MatHang(String name, String nhom, double gia_mua, double gia_ban) {
        this.ID = ++cnt;
        this.name = name;
        this.nhom = nhom;
        this.gia_mua = gia_mua;
        this.gia_ban = gia_ban;
        this.loi_nhuan = gia_ban - gia_mua;
    }
    
    @Override
    public int compareTo(MatHang o){
        if(this.loi_nhuan > o.loi_nhuan) return -1;
        else return 1;
    }
    
    @Override
    public String toString()
    {
        return this.ID + " " + this.name + " " + this.nhom + " " + String.format("%.2f",this.loi_nhuan);
    }
    
}
