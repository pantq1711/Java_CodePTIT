import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
public class J07084 {
    
    public static void main(String[] args) throws ParseException, FileNotFoundException{
        Scanner sc = new Scanner(new File("ONLINE.in"));
        ArrayList <Online> arr = new ArrayList <>();
        int n = Integer.parseInt(sc.nextLine());
        while(n-- >0) arr.add(new Online(sc.nextLine(), sc.nextLine(), sc.nextLine()));
        Collections.sort(arr);
        for(Online o : arr){
            System.out.println(o);
        }
    }
}
//3
//Do Viet Anh
//11/12/2021 16:35:00
//11/12/2021 17:35:00
//Le Tuan Anh
//11/12/2021 16:45:00
//11/12/2021 18:15:00
//Nguyen Tuan Anh
//11/12/2021 17:00:00
//11/12/2021 19:15:00