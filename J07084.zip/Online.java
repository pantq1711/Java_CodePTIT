/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.time.temporal.ChronoUnit;
import java.text.ParseException;
public class Online implements Comparable<Online> {
    
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    
    private String name;
    private Date start_Time, end_Time;
    private long online_Time;
    public Online(String name, String start_Time, String end_Time) throws ParseException{
        this.name = name.trim();
        this.start_Time = sdf.parse(start_Time);
        this.end_Time = sdf.parse(end_Time);
        this.online_Time = ChronoUnit.MINUTES.between(this.start_Time.toInstant(), this.end_Time.toInstant());
    }
    
    @Override
    public int compareTo(Online o){
        if(this.online_Time == o.online_Time){
            return this.name.compareTo(o.name);
        }
        else if(this.online_Time < o.online_Time) return 1;
        return -1;
    }
    
    @Override
    public String toString(){
        return this.name + " " + this.online_Time;
    }
}
