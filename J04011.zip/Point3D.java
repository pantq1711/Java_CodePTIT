/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class Point3D {
    private int x, y, z;

    public Point3D(int x, int y, int z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public static boolean check(Point3D p1, Point3D p2, Point3D p3, Point3D p4) 
    {
        Point3D ab = new Point3D(p2.x - p1.x, p2.y - p1.y, p2.z - p1.z);
        Point3D ac = new Point3D(p3.x - p1.x, p3.y - p1.y, p3.z - p1.z);
        Point3D ad = new Point3D(p4.x - p1.x, p4.y - p1.y, p4.z - p1.z);
        
        //tim toa do x, y, z cua tich vector ab * ac
        int d1 = ab.y * ac.z - ab.z * ac.y;
        int d2 = ab.z * ac.x - ab.x * ac.z;
        int d3 = ab.x * ac.y - ab.y * ac.x;

        return ad.x * d1 + ad.y * d2 + ad.z * d3 == 0;
        
    }
}

