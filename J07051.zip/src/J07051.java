/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.text.ParseException;
public class J07051 {
    
    public static void main(String[] args) throws FileNotFoundException, ParseException{
        
        Scanner sc = new Scanner(new File("KHACHHANG.in"));
        ArrayList <KhachHang> arr = new ArrayList <>();
        int t = Integer.parseInt(sc.nextLine());
        while(t-- >0) arr.add(new KhachHang(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine(), Integer.parseInt(sc.nextLine())));
        Collections.sort(arr);
        for(KhachHang kh : arr)
        {
            System.out.println(kh);
        }
    }
}
