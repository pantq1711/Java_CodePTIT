import java.util.*;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Date;
import java.time.temporal.ChronoUnit;
public class KhachHang implements Comparable<KhachHang>{
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    private String ID, Name, Number_Room;
    private Date End_Day, Start_Day;
    private long Fee;
    private long Unit_Price, Total_Money, Days_Stay;

    public KhachHang(int ID, String Name, String Number_Room, String End_Day, String Start_Day, long Fee) throws ParseException{
        this.ID = "KH" + String.format("%02d", ID);
        this.Name = "";
        this.Number_Room = Number_Room;
        String [] words = Name.trim().split("\\s+");
        for(String word : words){
            this.Name += word.toUpperCase().charAt(0);
            for(int j=1; j<word.length(); ++j) this.Name += word.toLowerCase().charAt(j);
            this.Name += " ";
        }
        this.End_Day = sdf.parse(End_Day);
        this.Start_Day = sdf.parse(Start_Day);
        this.Fee = Fee;
        switch(Number_Room.charAt(0)){
            case '1':
                this.Unit_Price = 25;
                break;
            case '2':
                this.Unit_Price = 34;
                break;
            case '3':
                this.Unit_Price = 50;
                break;
            default:
                this.Unit_Price = 80;
        }
        this.Days_Stay = ChronoUnit.DAYS.between(this.End_Day.toInstant(), this.Start_Day.toInstant()) + 1;
        this.Total_Money = this.Days_Stay * this.Unit_Price + this.Fee;
    }
    @Override
    public int compareTo(KhachHang o){
        return (int)(o.Total_Money - this.Total_Money);
    }
    @Override
    public String toString(){
        return this.ID + " " + this.Name + this.Number_Room + " " + this.Days_Stay + " " + this.Total_Money;
    }
}