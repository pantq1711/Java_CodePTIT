import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
public class J07051{
    public static void main(String[] args) throws ParseException, FileNotFoundException{
        Scanner sc = new Scanner(new File("KHACHHANG.in"));
        int t = Integer.parseInt(sc.nextLine());
        ArrayList <KhachHang> arr = new ArrayList <>();
        for(int i=1; i<=t; ++i){
            arr.add(new KhachHang(i, sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine(), Long.parseLong(sc.nextLine())));
        }
        Collections.sort(arr);
        for(KhachHang kh : arr){
            System.out.println(kh);
        }
    }
}