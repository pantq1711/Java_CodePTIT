/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class J05034 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = Integer.parseInt(sc.nextLine());
        ArrayList <SinhVien> arr = new ArrayList <>();
        while(t-- >0) arr.add(new SinhVien(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine()));
        Collections.sort(arr);
        int q = Integer.parseInt(sc.nextLine());
        while(q-- >0)
        {
            String s = sc.nextLine();
            for(SinhVien sv : arr){
                if(sv.getTen_dn().compareTo(s) == 0) System.out.println(sv);
            }
        }
    }
}
