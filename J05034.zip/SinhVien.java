/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class SinhVien implements Comparable<SinhVien> {
    
    public static int cnt = 0;
    
    private int stt;
    
    private String ID, ho_ten, lop, email, ten_dn;

    public SinhVien(String ID, String ho_ten, String lop, String email, String ten_dn) {
        this.stt = ++cnt;
        this.ID = ID;
        this.ho_ten = ho_ten;
        this.lop = lop;
        this.email = email;
        this.ten_dn = ten_dn;
    }
    
    @Override
    public int compareTo(SinhVien o)
    {
        return this.ho_ten.compareTo(o.ho_ten);
    }

    public String getTen_dn() {
        return ten_dn;
    }
    
    @Override
    public String toString()
    {
        return stt + " " + ID + " " + ho_ten + " " + lop + " " + email + " " + ten_dn;
    }
}
