
import java.util.ArrayList;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
public class reg implements Comparable<reg>{
    private String ID, name, nameINS, nameDoi;
    
    private static int cnt = 1;
    
    private int quantity;
    
    private ArrayList <String> arr;

    public reg(Scanner sc) {
        arr = new ArrayList <>();
        String s = sc.nextLine();
        String [] words = s.trim().split("\\s+");
        ID = words[0];
        quantity = Integer.parseInt(words[1]);
        for(int i=0; i<quantity; ++i)
        {
            arr.add(sc.nextLine());
        }
    }

    public void setNameDoi(String n)
    {
        nameDoi = n;
    }
    public ArrayList<String> getArrayList()
    {
        return arr;
    }
    
    public void setNameINS(String n)
    {
        nameINS = n;
    }
    
    public String getID()
    {
        return ID;
    }
    
    @Override
    public int compareTo(reg o)
    {
        if(this.nameINS.equals(o.nameINS)) return this.nameDoi.compareTo(o.nameDoi);
        return this.nameINS.compareTo(o.nameINS);
    }
    
    @Override
    public String toString()
    {
        return String.format("team%02d", cnt++) + " " + nameDoi + " " + nameINS;
    }
}
