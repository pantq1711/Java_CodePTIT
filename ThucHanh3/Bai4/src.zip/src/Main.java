/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
public class Main {
    
    public static void main(String[] args) throws FileNotFoundException {
        
        ArrayList <reg> arr = new ArrayList <>();
        Scanner sc = new Scanner(new File("INSTITUTION.in"));
        Map <String, ins> map = new HashMap<>();
        int t = Integer.parseInt(sc.nextLine());
        while(t-- >0)
        {
            ins i = new ins(sc.nextLine());
            map.put(i.getID(), i);
        }
        sc = new Scanner(new File("REGISTER.in"));        
        t = Integer.parseInt(sc.nextLine());
        while(t-- >0)
        {
            reg r = new reg(sc);
            ArrayList <String> a = new ArrayList<>();
            a.addAll(r.getArrayList());
            for(int i=0; i<a.size(); ++i)
            {
                System.out.println(a.get(i));
                r.setNameDoi(a.get(i));
                r.setNameINS(map.get(r.getID()).getName());
                arr.add(r);                
            }
        }
        Collections.sort(arr);
        for(reg r : arr)
        {
            System.out.println(r);
        }
    }
}
