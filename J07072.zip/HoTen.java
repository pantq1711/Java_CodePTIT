/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class HoTen implements Comparable<HoTen>{
    
    public String chuanhoa(String s){
        String res = "";
        String [] words = s.trim().split("\\s+");
        for(String word : words) res += word.toUpperCase().charAt(0) + word.toLowerCase().substring(1) + " ";
        return res.trim();
    }
    
    private String ho_Ten, ten;

    public HoTen(String ho_Ten) {
        this.ho_Ten = chuanhoa(ho_Ten);
        ten = get_ten();
    }
    
    public String get_ten(){
        String [] words = this.ho_Ten.split("\\s+");
        return words[words.length - 1];
    }
    
    @Override
    public int compareTo(HoTen o){
        if(this.ten.compareTo(o.ten) == 0) return this.ho_Ten.compareTo(o.ho_Ten);
        return this.ten.compareTo(o.ten);
    }
    
    @Override
    public String toString(){
        return this.ho_Ten;
    }
}
