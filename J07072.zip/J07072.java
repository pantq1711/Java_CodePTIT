/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
public class J07072 {
    
    public static void main(String[] args) throws FileNotFoundException{
        Scanner sc = new Scanner(new File("DANHSACH.in"));
        ArrayList <HoTen> arr = new ArrayList <>();
        
        while(sc.hasNextLine()){
            arr.add(new HoTen(sc.nextLine()));
        }
        Collections.sort(arr);
        for(HoTen ht : arr){
            System.out.println(ht);
        }
    }
}
