/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class NhanVien implements Comparable <NhanVien> {
    
    public static int cnt = 0;
    
    private String ID, ten;
    
    private int luong_ngay, so_ngay, phu_cap;
    
    private String chuc_vu;
    
    public int get_luong_thang()
    {
        return luong_ngay * so_ngay;
    }
    
    public int get_thuong()
    {
        if(so_ngay >= 25) return get_luong_thang() * 20 / 100;
        else if(so_ngay >= 22) return get_luong_thang() * 10 / 100;
        else return 0;
    }
    

    public NhanVien(String ten, int luong_ngay, int so_ngay, String chuc_vu) {
        this.ID = String.format("NV%02d", ++cnt);
        this.ten = ten;
        this.luong_ngay = luong_ngay;
        this.so_ngay = so_ngay;
        this.chuc_vu = chuc_vu;
        switch(chuc_vu.charAt(0)){
            case 'G':
                this.phu_cap = 250000;
                break;
            case 'P':
                this.phu_cap = 200000;
                break;
            case 'T':
                this.phu_cap = 180000;
                break;
            default :
                this.phu_cap = 150000;
        }
    }
    
    public int tong_tien_luong()
    {
        return this.get_luong_thang() + this.get_thuong() + this.phu_cap;
    }
    
    @Override
    public int compareTo(NhanVien o)
    {
        return o.tong_tien_luong() - this.tong_tien_luong();
    }
    
    @Override
    public String toString()
    {
        return this.ID + " " + this.ten + " " + this.get_luong_thang() + " " + this.get_thuong() + " " + this.phu_cap + " " + this.tong_tien_luong();
    }
}
