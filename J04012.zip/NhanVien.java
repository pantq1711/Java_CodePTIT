/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class NhanVien {
    public static int cnt = 1;
          
    private String ID, name;
    
    private int luong_basic, so_ngay;
    private String chucvu;
    private int tien_thuong, phu_cap, thu_nhap;

    public static String chuanhoa(String s){
        String res = "";
        String [] words = s.trim().split("\\s+");
        for(String word : words) res += word.toUpperCase().charAt(0) + word.toLowerCase().substring(1) + " ";
        return res.trim();
    }
    
    public int getluong_thang(){
        return this.luong_basic * this.so_ngay;
    }
    
    public int gettien_thuong(){
        if(this.so_ngay >= 25) return this.getluong_thang() * 20 / 100;
        else if(this.so_ngay >= 22) return this.getluong_thang() * 10 / 100;
        else return 0;
    }
    
    public int getphu_cap(){
        char cv = this.chucvu.charAt(0);
        switch(cv){
            case 'G':
                return 250000;
            case 'P':
                return 200000;
            case 'T':
                return 180000;
            default:
                return 150000;
        }
    }
    
    public NhanVien(String name, int luong_basic, int so_ngay, String chucvu) {
        this.ID = String.format("NV%02d", cnt++);
        this.name = chuanhoa(name);
        this.luong_basic = luong_basic;
        this.so_ngay = so_ngay;
        this.chucvu = chucvu.trim();
    }
    
    public int getthu_nhap(){
        return this.getluong_thang() + this.gettien_thuong() + this.getphu_cap();
    }
    
    @Override
    public String toString(){
        return this.ID + " " + this.name + " " + this.getluong_thang() + " " + this.gettien_thuong() + " " + this.getphu_cap() + " " + this.getthu_nhap();
    }
}
