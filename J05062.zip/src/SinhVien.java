class SinhVien implements Comparable <SinhVien> {
 
    private String ten;
    
    private double gpa;
    
    private int drl;
    
    private String status;

    public SinhVien(String ten , String line) {
        this.ten = ten;
        String [] words = line.trim().split("\\s+");
        this.gpa = Double.parseDouble(words[0]);
        this.drl = Integer.parseInt(words[1]);
    }

    public double getGpa() {
        return gpa;
    }

    public String getStatus() {
        return status;
    }
    
    public String getTen()
    {
        return ten;
    }
    
    public void setStatus(boolean check)
    {
        if(check) status = "KHONG";
        else {
            
            if(gpa >= 3.6 && drl >= 90 ) status = "XUATSAC";
            else if(gpa >= 3.2 && drl >= 80) status = "GIOI";
            else if(gpa >= 2.5 && drl >= 70) status = "KHA";
            else status = "KHONG";
        }
    }
    
    @Override
    public int compareTo(SinhVien o)
    {
        if(this.gpa > o.gpa) return 1;
        else return -1;
    }
    
    @Override
    public String toString()
    {
        return ten + ": ";
    }
}