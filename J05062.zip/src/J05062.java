/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;

public class J05062 {
    
    public static void main(String[] args) {
        
        Map <Integer, SinhVien> map = new HashMap <>();
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt(), m = sc.nextInt();
        sc.nextLine();
        ArrayList <SinhVien> arr = new ArrayList <>();
        for(int i=0; i<n; ++i)
        {
            SinhVien sv = new SinhVien(sc.nextLine(), sc.nextLine());
            arr.add(sv);
            map.put(i, sv);
        }
        ArrayList <SinhVien> arr1 = new ArrayList<>();
        arr1.addAll(arr);        
        Collections.sort(arr1);
        double dtb = arr1.get(n - m).getGpa();
        boolean check;
        for(int i=0; i<n; ++i)
        {
            check = false;
            if(arr.get(i).getGpa() < dtb) check = true;
            map.get(i).setStatus(check);
            System.out.println(arr.get(i) + map.get(i).getStatus());
        }
    }
}
//3 2
//Nguyen Van Nam
//3.59 75
//Tran Hong Ngoc
//3.61 90
//Do Van An
//3.22 90