/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class KhachHang implements Comparable <KhachHang> {
    
    public static int cnt = 0;
    
    public String ID, loai_SD;
    
    public double chiso_cu, chiso_moi;

    public KhachHang(String loai_SD, double chiso_cu, double chiso_moi) {
        this.ID = String.format("KH%02d", ++cnt);
        this.loai_SD = loai_SD;
        this.chiso_cu = chiso_cu;
        this.chiso_moi = chiso_moi;
    }
    
    public int he_so(){
        
        switch(loai_SD.charAt(0)){
            case 'K':
                return 3;
            case 'N':
                return 5;
            case 'T':
                return 4;
            default :
                return 2; 
        }
    }
    
    public double tien(){
        return 550 * he_so() * (chiso_moi - chiso_cu);
    }
    
    public double phutroi()
    {
        double chenhlech = chiso_moi - chiso_cu;
        if(chenhlech < 50) return 0;
        else if(chenhlech > 100) return Math.round(tien());
        else return Math.round(tien() * 35 / 100);
    }
    
    public double tongtien(){
        return phutroi() + tien();
    }
    
    @Override
    public int compareTo(KhachHang o)
    {
        if(this.tongtien() < o.tongtien()) return 1;
        else return -1;
    }
    @Override
    public String toString()
    {
        return String.format("%s %d %.0f %.0f %.0f", ID, this.he_so(), tien(), phutroi(), tongtien());
    }
    
}