/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class J05051 {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList <KhachHang> arr = new ArrayList <>();
        int t = Integer.parseInt(sc.nextLine());
        while(t-- >0) arr.add(new KhachHang(sc.nextLine(), Double.parseDouble(sc.nextLine()), Double.parseDouble(sc.nextLine())));
        Collections.sort(arr);
        for(KhachHang kh : arr)
        {
            System.out.println(kh);
        }
    }
}
//3
//KD
//400
//555
//NN
//58
//400
//CN
//150
//700