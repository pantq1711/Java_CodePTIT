/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.time.temporal.ChronoUnit;
import java.time.*;
import java.time.format.DateTimeFormatter;
public class KhachHang implements Comparable <KhachHang> {
    
    public static int stt = 0;
    
    public static boolean check = false;
    
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    
    private String ID, name, IDRoom;
    
    private double feeKH;
    
    private long countDays, price;
    
    private LocalDate startDay, endDay;

   public KhachHang(String name, String IDRoom, String startDay, String endDay) {
    ID = String.format("KH%02d", ++stt);
    this.name = name;
    this.IDRoom = IDRoom;
    this.startDay = LocalDate.parse(startDay, dtf);
    this.endDay = LocalDate.parse(endDay, dtf);
    countDays = (int)ChronoUnit.DAYS.between(this.startDay, this.endDay);
    if (countDays == 0) 
    {
        check = true;
        countDays = 1;
    }
}

    
    public double getDiscount()
    {
        if(countDays < 10) return 0.0;
        else if(countDays >= 10 && countDays < 20) return 0.02;
        else if(countDays >= 20 && countDays < 30) return 0.04;
        else return 0.06;
    }
    
    public void setPrice(int n)
    {
        price = n;
    }
    
    public char getIDKH()
    {
        return IDRoom.charAt(2);
    }
    
    public void setFee(double n)
    {
        feeKH = n;
    }
    
    public double getTien()
    {
        return countDays * price * (1 + feeKH) * (1 - getDiscount()); 
    }
    
    @Override
    public int compareTo(KhachHang o)
    {
        if(o.countDays > this.countDays) return 1;
        else return -1;
    }
    
    @Override
    public String toString()
    {
        String tmp = Long.toString(countDays);
        if(check == true && countDays == 1){
            tmp = "0";
            check = false;
        }
        return String.format("%s %s %s %s %.2f", ID, name, IDRoom, tmp, getTien());
    }
    
}
