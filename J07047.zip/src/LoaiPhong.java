/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
public class LoaiPhong {
    
    private String line;
    
    private char ID;
    
    private String nameRoom;
    
    private int pricePerDay;
    
    private double fee;

    public LoaiPhong(String line) {
        String [] words = line.trim().split("\\s+");
        this.ID = words[0].charAt(0);
        this.nameRoom =  words[1];
        this.pricePerDay = Integer.parseInt(words[2]);
        this.fee = Double.parseDouble(words[3]);
    }

    public char getID() {
        return ID;
    }

    public int getPricePerDay() {
        return pricePerDay;
    }

    public double getFee() {
        return fee;
    }
    
    
}
