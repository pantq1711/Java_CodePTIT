/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.io.*;
public class J07047 {
    
    public static void main(String[] args) throws FileNotFoundException{
        
        Scanner sc = new Scanner(new File("DATA.in"));
        Map <Character, LoaiPhong> map = new HashMap <>();
        int t = Integer.parseInt(sc.nextLine());
        while(t-- >0)
        {
            LoaiPhong lp = new LoaiPhong(sc.nextLine());
            map.put(lp.getID(), lp);
        }
        t = Integer.parseInt(sc.nextLine());
        ArrayList <KhachHang> arr = new ArrayList <>();
        while(t-- >0)
        {
            KhachHang kh = new KhachHang(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine());
            LoaiPhong lp = map.get(kh.getIDKH());
            kh.setFee(lp.getFee());
            kh.setPrice(lp.getPricePerDay());
            arr.add(kh);
        }
        Collections.sort(arr);
        for(KhachHang kh : arr)
        {
            System.out.println(kh);
        }
    }
}