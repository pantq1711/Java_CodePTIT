import java.util.*;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Date;
import java.time.temporal.ChronoUnit;
public class KhachHang implements Comparable<KhachHang> {
    
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    
    public Date ngayNhan, ngayTra;
    
    public static int cnt = 0;
    
    public String ID, ten;
    
    public String soPhong;
    
    public int tiendv;
    
    public static String chuanhoa(String s)
    {
        String res = "";
        String [] words = s.trim().split("\\s+");
        for(String word : words) res += word.toUpperCase().charAt(0) + word.toLowerCase().substring(1) + " ";
        return res.trim();
    }

    public KhachHang(String ten, String soPhong, String ngayNhan, String ngayTra, int tiendv) throws ParseException{
        this.ID = String.format("KH%02d", ++cnt);
        this.ten = chuanhoa(ten);
        this.soPhong = soPhong;
        this.ngayNhan = sdf.parse(ngayNhan);
        this.ngayTra = sdf.parse(ngayTra);
        this.tiendv = tiendv;
    }
    
    public int getNgay()
    {
        return (int) ChronoUnit.DAYS.between(ngayNhan.toInstant(), ngayTra.toInstant()) + 1;
    }
    
    public int getGia()
    {
        switch(soPhong.charAt(0))
        {
            case '1':
                return 25;
            case '2':
                return 34;
            case '3':
                return 50;
            default :
                return 80;
        }
    }
    
    public int tongTien()
    {
        return getNgay() * getGia() + tiendv;
    }
    
    @Override
    public int compareTo(KhachHang o)
    {
        return o.tongTien() - this.tongTien();
    }
    
    @Override
    public String toString()
    {
        return ID + " " + ten + " " + soPhong + " " + getNgay() + " " + tongTien();
    }
}