import java.util.*;
import java.text.ParseException;
public class J05016 {
    
    public static void main(String[] args) throws ParseException{
        
        Scanner sc = new Scanner(System.in);
        ArrayList <KhachHang> arr = new ArrayList <>();
        int t = Integer.parseInt(sc.nextLine());
        while(t-- >0) arr.add(new KhachHang(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine(), Integer.parseInt(sc.nextLine())));
        Collections.sort(arr);
        for(KhachHang kh : arr)
        {
            System.out.println(kh);
        }
    }
}