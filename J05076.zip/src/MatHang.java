/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
public class MatHang {
    
    public String ID, ten, loai;

    public MatHang(String ID, String ten, String loai) {
        this.ID = ID;
        this.ten = ten;
        this.loai = loai;
    }

    public String getID() {
        return ID;
    }


    public double getLoai() {
        char c = loai.charAt(0);
        if(c == 'A') return 0.08;
        else if(c == 'B') return 0.05;
        else return 0.02;
    }

    @Override
    public String toString()
    {
        return ID + " " + ten;
    }
    
}
