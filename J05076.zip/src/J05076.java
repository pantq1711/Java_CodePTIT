/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class J05076 {
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        int t = Integer.parseInt(sc.nextLine());
        ArrayList <MatHang> arr = new ArrayList <>();
        Map <String, MatHang> map = new HashMap<>();
        for(int i=0; i<t; ++i)
        {
             MatHang mh = new MatHang(sc.nextLine(), sc.nextLine(), sc.nextLine());
             map.put(mh.getID(), mh);
        }
        ArrayList <ThongKe> arr1 = new ArrayList <>();
        t = Integer.parseInt(sc.nextLine());
        for(int i=0; i<t; ++i)
        {
            ThongKe tk = new ThongKe(sc.nextLine());
            arr1.add(tk);
            arr1.get(i).setXuat(map.get(tk.getID()).getLoai());
        }
        for(ThongKe tk : arr1)
        {
            System.out.println(map.get(tk.getID()) + " " + tk);
        }
    }
}
//2
//A001
//Tu lanh
//A
//P002
//May giat
//B
//2
//A001 500 100 300
//P002 1000 1000 500