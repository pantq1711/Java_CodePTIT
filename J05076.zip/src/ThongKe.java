/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
public class ThongKe {
   
    private String ID;
    
    private int soLuongNhap, donGiaNhap, soLuongXuat;

    private int tongNhap, tongXuat;
    public ThongKe(String s) {
        String [] words = s.trim().split("\\s+");
        this.ID = words[0];
        this.soLuongNhap = Integer.parseInt(words[1]);
        this.donGiaNhap = Integer.parseInt(words[2]);
        this.soLuongXuat = Integer.parseInt(words[3]);
        this.tongNhap = soLuongNhap  * donGiaNhap;
    }

    public String getID() {
        return ID;
    }
 
    
    public void setXuat(double n)
    {
        tongXuat += (int) Math.round(donGiaNhap * soLuongXuat * (1 + n));
    }
    
    
    @Override
    public String toString()
    {
        return tongNhap + " " + tongXuat;
    }
}
