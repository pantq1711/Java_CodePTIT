/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class ThiSinh implements Comparable<ThiSinh>{
    private String ID, name;
    private String point;
    private String type_Ethnic, area;
    private double total_Point;
    
    public String chuanhoa(String s){
        String res = "";
        String [] words = s.trim().split("\\s+");
        for(String word : words) res += word.toUpperCase().charAt(0) + word.toLowerCase().substring(1) + " ";
        return res.trim();
    }
    
    public String getstatus(){
        if(this.total_Point >= 20.5) return "Do";
        else return "Truot";
    }
    
    public double getpriority_Point(){
        if(this.area.charAt(0) == '1') return 1.5;
        else if(this.area.charAt(0) == '2') return 1.0;
        else return 0.0;
    }
    public ThiSinh(int ID, String name, String point, String type_Ethnic, String area) {
        this.ID = String.format("TS%02d", ID);
        this.name = chuanhoa(name);
        this.type_Ethnic = type_Ethnic;
        this.area = area.trim();
        this.total_Point = getpriority_Point() + Double.parseDouble(point);
        if(this.type_Ethnic.toLowerCase().compareTo("kinh") != 0) this.total_Point += 1.5;
    }
    
    @Override
    public int compareTo(ThiSinh o){
        if(this.total_Point == o.total_Point){
            return this.ID.compareTo(o.ID);
        }
        else if(this.total_Point > o.total_Point) return -1;
        return 1;
    }
    @Override
    public String toString(){
        return String.format("%s %s %.1f %s", this.ID, this.name, this.total_Point, this.getstatus());
    }
    
}
