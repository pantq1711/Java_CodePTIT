/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
import java.util.Date;
import java.time.temporal.ChronoUnit;
import java.text.ParseException;
import java.text.SimpleDateFormat;
public class Gamer implements Comparable <Gamer> {
    
    SimpleDateFormat sdf = new SimpleDateFormat("hh:mm");
    
    private String ID, name;
    
    private Date start_Time, end_Time;
    
    private long hours, mins;

    public Gamer(String ID, String name, String start_Time, String end_Time) throws ParseException {
        this.ID = ID;
        this.name = name;
        this.start_Time = sdf.parse(start_Time);
        this.end_Time = sdf.parse(end_Time);
        this.hours = ChronoUnit.HOURS.between(this.start_Time.toInstant(), this.end_Time.toInstant());
        this.mins = ChronoUnit.MINUTES.between(this.start_Time.toInstant(), this.end_Time.toInstant()) - this.hours * 60;
    }
    
    @Override
    public int compareTo(Gamer o)
    {
        if(this.hours == o.hours) return (int)(o.mins - this.mins);
        return (int)(o.hours - this.hours);
    }
    
    @Override
    public String toString()
    {
        return String.format("%s %s %d gio %d phut", this.ID, this.name, this.hours, this.mins);
    }
    
}
