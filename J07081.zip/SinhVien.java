/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class SinhVien implements Comparable <SinhVien> {
    
    private String ID, full_Name, phone_Nums, email;
    private String last_Name, first_Name; 
    
    public SinhVien(String ID, String name, String phone_Nums, String email) {
        ID = ID.trim();
        this.ID = ID;
        this.full_Name = name;
        String [] words = name.split("\\s+");
        this.first_Name = words[words.length - 1];
        this.last_Name = name.substring(0, this.full_Name.length() - this.first_Name.length());
        this.phone_Nums = phone_Nums;
        this.email = email;
    }
    
    @Override
    public int compareTo(SinhVien o){
        if(this.first_Name.compareTo(o.first_Name) == 0)
        {
            if(this.last_Name.compareTo(o.last_Name) == 0)
            {
                return this.ID.compareTo(o.ID);
            }
            return this.last_Name.compareTo(o.last_Name);
        }
        return this.first_Name.compareTo(o.first_Name);
    }
    
    @Override
    public String toString(){
        return this.ID + " " + this.full_Name + " " + this.phone_Nums + " " + this.email;
    }
}