/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Anphan
 */
import java.util.*;
public class SinhVien implements Comparable <SinhVien> {
    
    private String ID, name, Class, Email;

    public SinhVien(String ID, String name, String Class, String Email) {
        this.ID = ID;
        this.name = name;
        this.Class = Class;
        this.Email = Email;
    }
    
    @Override
    public int compareTo(SinhVien o)
    {
        if(this.Class.compareTo(o.Class) == 0)
        {
            return this.ID.compareTo(o.ID);
        }
        return this.Class.compareTo(o.Class);
    }
    
    @Override
    public String toString()
    {
        return this.ID + " " + this.name + " " + this.Class + " " + this.Email;
    }
}
